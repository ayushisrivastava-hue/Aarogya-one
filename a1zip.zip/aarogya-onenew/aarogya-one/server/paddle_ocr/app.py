"""Private PaddleOCR helper for prescription image pages."""

import base64
import binascii
import os
from typing import Literal

import cv2
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from paddleocr import PaddleOCR

app = FastAPI(title="Aarogya One PaddleOCR", docs_url=None, redoc_url=None)
ocr = PaddleOCR(lang="en", use_doc_orientation_classify=True, use_doc_unwarping=True)


class ImagePage(BaseModel):
    mimeType: Literal["image/jpeg", "image/png", "image/webp"]
    imageBase64: str = Field(min_length=1, max_length=8_000_000)


class OcrRequest(BaseModel):
    images: list[ImagePage] = Field(min_length=1, max_length=5)


def extract_text(result) -> str:
    data = getattr(result, "json", {})
    if callable(data):
        data = data()
    body = data.get("res", data) if isinstance(data, dict) else {}
    if not isinstance(body, dict):
        return ""
    lines = body.get("rec_texts", [])
    return "\n".join(str(line).strip() for line in lines if str(line).strip())[:8000]


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/ocr")
def run_ocr(request: OcrRequest):
    if sum(len(page.imageBase64) for page in request.images) > 22_400_000:
        raise HTTPException(status_code=413, detail="Image payload too large")

    pages = []
    for page in request.images:
        try:
            raw = base64.b64decode(page.imageBase64, validate=True)
        except (binascii.Error, ValueError):
            raise HTTPException(status_code=400, detail="Invalid image encoding")
        image = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image is None or image.shape[0] * image.shape[1] > 24_000_000:
            raise HTTPException(status_code=400, detail="Invalid or oversized image")
        result = ocr.predict(input=image)
        text = "\n".join(filter(None, (extract_text(item) for item in result)))
        pages.append({"text": text})
    return {"pages": pages}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=os.getenv("PADDLE_OCR_HOST", "127.0.0.1"), port=int(os.getenv("PADDLE_OCR_PORT", "8790")))
