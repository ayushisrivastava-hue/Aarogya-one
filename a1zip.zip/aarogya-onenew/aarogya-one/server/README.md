# Aarogya One — chat backend

A small Express server that keeps AI credentials on the backend. Prescription
scanning uses a self-hosted Qwen3-VL vision model through an OpenAI-compatible
endpoint. Chat, prescription explanations, report explanations, and health
tips continue to use Gemini. The server can also log chat exchanges to MongoDB.
Prescription scanning optionally runs uploaded page images through a private
PaddleOCR service first, then gives its text and the original images to Qwen.

## Why there's a second database here (MongoDB) when Supabase already exists

Supabase (Postgres) stays exactly as it was — it's still the system of
record for everything that matters: hospitals, appointments, tokens,
prescriptions, medicines, complaints, beds, user accounts. Moving all of
that to MongoDB would mean rebuilding auth, row-level security, and the
realtime queue updates from scratch for no real benefit — Supabase already
does all of that well.

MongoDB here is used for one specific, separate thing it's naturally good
at: a loose log of chat messages (`chat_logs`), which doesn't need strict
columns or relations. That's a reasonable, honest way to actually use
MongoDB in this project without destabilizing the parts that already work.
If you had a specific reason to move more into MongoDB, tell me what it is
and we can plan that properly — but by default this keeps it scoped.

## Setup

```bash
cd server
npm install
cp .env.example .env
```

Then fill in `.env`:
- `GEMINI_API_KEY` - used by chat, report/prescription explanations, and health tips.
- `QWEN_VISION_BASE_URL` and `QWEN_VISION_MODEL` - point to the private Qwen server used for prescription scanning.
- `PADDLE_OCR_URL` - private PaddleOCR service URL; if it is offline, Qwen still reads the images.
- `MONGODB_URI` — from a free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster → Connect → Drivers. If you skip this, the chatbot still works; it just won't save a log.
- `ALLOWED_ORIGINS` — the URL your frontend runs on (e.g. what Live Server shows you).

## Start the open-weight prescription model

Prescription scanning uses a self-hosted Qwen3-VL model. On a Linux machine with a supported GPU environment, install vLLM and start the model:

```bash
pip install vllm
vllm serve Qwen/Qwen3-VL-8B-Instruct --host 127.0.0.1 --port 8000
```

The `server/.env.example` values point Express at `http://127.0.0.1:8000/v1`. If the model runs on another private host, update `QWEN_VISION_BASE_URL`. Do not expose the model server publicly; the browser should call Express only. See the [Qwen3-VL model card](https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct) for serving options and hardware requirements. Prescription PDFs are rendered in the browser and limited to five pages per scan.

## Start PaddleOCR

PaddleOCR runs as a separate local Python service. In another terminal on a supported Python/PaddlePaddle machine (Linux or WSL is recommended), install and start it:

```bash
cd server/paddle_ocr
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

It listens on `127.0.0.1:8790`, matching `PADDLE_OCR_URL` in the server environment. PaddleOCR text is only a clue for Qwen; Qwen also checks the original images. OCR and handwriting recognition can be wrong, so users must review every candidate. See the [PaddleOCR documentation](https://www.paddleocr.ai/main/en/version3.x/pipeline_usage/OCR.html) for installation and supported models.

Run it:
```bash
npm start
```
You should see `listening on http://localhost:8787`.

## Connecting the frontend to it

In `js/app.js`, near the top, there's:
```js
const CHAT_API_URL = 'http://localhost:8787/api/chat';
```
This already points at the server running locally. When you deploy the
server somewhere (Render, Railway, Fly.io all have free tiers that work for
this), change this line to that URL, and add your deployed frontend's URL
to `ALLOWED_ORIGINS` in the server's `.env`.

## Swapping the AI provider

The `/api/chat`, `/api/explain-prescription`, `/api/explain-report`, and
`/api/health-tips` routes use Gemini. Prescription image extraction uses the
separately configured Qwen3-VL OpenAI-compatible endpoint.

## What this server does *not* do

It doesn't touch your Supabase data or replace Supabase auth. The server
supports AI features; prescription scanning additionally requires the Qwen
service to be running. Other app features (login, booking, queue, pharmacy,
complaints, beds) work without it.
