// Minimal backend for the Aarogya One AI assistant.
//
// Why this exists at all: the frontend (index.html/js/app.js) is a static
// site with no server of its own — it talks to Supabase directly, which is
// fine because Supabase's anon key is *meant* to be public (access is
// controlled by row-level security instead). An AI provider's API key is
// different: it must never be shipped to the browser, or anyone could copy
// it out of your page source and run up your bill. So this one small
// endpoint exists purely to hold that key server-side and forward requests.
//
// It also logs each exchange to MongoDB, mostly so you have a real,
// separate MongoDB database in the project, as asked for — see README.md
// in this folder for what it's for and what it isn't.

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { MongoClient } from 'mongodb';

const {
  GEMINI_API_KEY,
  GEMINI_MODEL = 'gemini-3.5-flash-lite',
  QWEN_VISION_BASE_URL = 'http://127.0.0.1:8000/v1',
  QWEN_VISION_MODEL = 'Qwen/Qwen3-VL-8B-Instruct',
  QWEN_VISION_API_KEY = '',
  QWEN_VISION_TIMEOUT_MS = '120000',
  PADDLE_OCR_URL = 'http://127.0.0.1:8790/ocr',
  PADDLE_OCR_TIMEOUT_MS = '60000',
  MONGODB_URI,
  MONGODB_DB = 'aarogya_one',
  MONGODB_COLLECTION = 'chat_logs',
  ALLOWED_ORIGINS = '',
  PORT = 8787,
} = process.env;

if (!GEMINI_API_KEY) {
  console.warn('[aarogya-server] GEMINI_API_KEY is not set - AI routes will fail until you add it to server/.env');
}
if (!MONGODB_URI) {
  console.warn('[aarogya-server] MONGODB_URI is not set — chat logging to MongoDB will be skipped.');
}

const app = express();
app.use(express.json({ limit: '24mb' })); // report and rendered prescription pages arrive as base64

const allowList = ALLOWED_ORIGINS.split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: allowList.length ? allowList : true, // true = reflect any origin; fine for local dev, tighten before going live
}));

// --- MongoDB: one shared connection, reused across requests -------------
let mongoCollection = null;
async function getMongoCollection() {
  if (!MONGODB_URI) return null;
  if (mongoCollection) return mongoCollection;
  const client = new MongoClient(MONGODB_URI);
  await client.connect();
  mongoCollection = client.db(MONGODB_DB).collection(MONGODB_COLLECTION);
  return mongoCollection;
}

const SYSTEM_PROMPT = `You are the in-app assistant for Aarogya One, a government hospital app in India.
You help with: how to book an appointment, how the live token/queue works, checking medicine
availability, finding prescriptions, filing or checking a complaint, checking bed availability,
and general navigation of the app.

Navigation map: From the landing page, use Get started, then choose Patient portal or
Staff portal. The top navigation has Home, About, Log out (when signed in), and Emergency.
In the patient portal, the left dashboard menu has Token & booking, Prescriptions, Medicines,
Complaints, Bed availability, My reports, and Health tips. Token & booking is where a patient
selects a hospital, department, doctor, and books an appointment; it also shows the live token
and queue position. Prescriptions shows saved prescriptions and the explanation button.
Medicines searches hospital stock. Complaints has File complaint and Check status.
Bed availability shows ward and bed status. My reports uploads a photo or PDF and explains it.
Health tips asks for activity, diet, and goal, then shows suggestions. The dashboard Emergency
button opens emergency guidance; emergencies do not require booking or login.
In the staff portal, the left menu has Queue, Pharmacy, Complaints, and Beds. Queue calls the
next token, adds walk-ins, and saves prescriptions. Pharmacy manages medicine stock and dispenses
prescriptions. Complaints manages patient complaints. Beds registers numbered beds and changes
their available or occupied status. Staff accounts are created by an administrator, not by staff
self-signup.
You may give general, widely-known health information (e.g. what a common symptom usually means,
general hygiene or first-aid advice), but you must NEVER diagnose a specific condition, never
recommend a specific medicine or dosage, and never tell someone their symptoms are not serious.
For anything that sounds urgent or serious, clearly tell the person to use the Emergency tab or go
straight to the Emergency department — do not try to triage it yourself.
People may attach a photo (a prescription label, a medicine packet, a report, a visible symptom like a
rash). You can describe what you see and give the same kind of general information as above, but the
same rule applies: never diagnose, never recommend a specific dosage, and send anything that looks
urgent straight to the Emergency tab instead of assessing it yourself.
Keep answers short (2-4 sentences unless the person asks for a list), warm, and in plain language.
If you don't know something about this specific hospital (exact hours, a specific doctor's
availability, personal records), say so honestly and tell them which part of the app or which desk
to check instead of guessing.`;

app.post('/api/chat', async (req, res) => {
  try {
    const { message, history = [], role = null, context = null, attachment = null } = req.body || {};
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'message is required' });
    }
    if (!GEMINI_API_KEY) {
      return res.status(500).json({ error: 'Server is not configured with an AI API key yet (see server/.env.example).' });
    }

    // The latest turn's content: plain text, or text + an attached photo.
    let latestContent = message;
    if (attachment && attachment.imageBase64 && attachment.mimeType) {
      latestContent = [
        { type: 'image', source: { type: 'base64', media_type: attachment.mimeType, data: attachment.imageBase64 } },
        { type: 'text', text: message },
      ];
    }

    const messages = [
      ...history
        .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
        .slice(-10)
        .map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
      { role: 'user', parts: toGeminiParts(latestContent) },
    ];

    let system = SYSTEM_PROMPT;
    if (role) system += `\nThe person you're talking to is signed in as: ${role}.`;
    if (context) system += `\nCurrent on-screen context (use this instead of guessing, but don't dump it back verbatim unless asked): ${context}`;

    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': GEMINI_API_KEY,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: messages,
        generationConfig: { maxOutputTokens: 400 },
      }),
    });

    if (!upstream.ok) {
      const detail = await upstream.text().catch(() => '');
      console.error('[aarogya-server] Gemini API error', upstream.status, detail);
      return res.status(502).json({ error: 'The AI provider returned an error. Check server logs and your API key.' });
    }

    const data = await upstream.json();
    const reply = (data.candidates?.[0]?.content?.parts || []).filter(b => b.text).map(b => b.text).join('\n').trim()
      || "Sorry, I didn't get a response.";

    // Log the exchange to MongoDB — best-effort; a logging failure should
    // never break the chat for the user.
    try {
      const col = await getMongoCollection();
      if (col) {
        await col.insertOne({
          message, reply, role, createdAt: new Date(),
        });
      }
    } catch (logErr) {
      console.error('[aarogya-server] MongoDB logging failed (chat still works):', logErr.message);
    }

    res.json({ reply });
  } catch (err) {
    console.error('[aarogya-server] /api/chat failed:', err);
    res.status(500).json({ error: 'Something went wrong handling that message.' });
  }
});

function toGeminiParts(content) {
  if (typeof content === 'string') return [{ text: content }];
  return content.map(block => {
    if (block.type === 'text') return { text: block.text };
    if (block.type === 'image' || block.type === 'document') {
      return { inlineData: { mimeType: block.source.media_type, data: block.source.data } };
    }
    return { text: '' };
  });
}

// Shared helper: one call to Gemini with a given system prompt + content, logged the same way as chat.
async function askGemini(system, userContent, logKind) {
  const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-goog-api-key': GEMINI_API_KEY,
    },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: toGeminiParts(userContent) }],
      generationConfig: { maxOutputTokens: 700 },
    }),
  });
  if (!upstream.ok) {
    const detail = await upstream.text().catch(() => '');
    console.error(`[aarogya-server] Gemini API error (${logKind})`, upstream.status, detail);
    throw new Error('AI provider error');
  }
  const data = await upstream.json();
  const text = (data.candidates?.[0]?.content?.parts || []).filter(b => b.text).map(b => b.text).join('\n').trim();
  try {
    const col = await getMongoCollection();
    if (col) await col.insertOne({ kind: logKind, reply: text, createdAt: new Date() });
  } catch (e) { console.error('[aarogya-server] MongoDB logging failed:', e.message); }
  return text || "Sorry, I couldn't put together an explanation for that.";
}

const MEDS_SYSTEM = `You explain prescriptions for patients of an Indian government hospital app, in plain,
simple language a non-medical person can understand. For each medicine listed, briefly say: (1) what
it's generally used for, (2) common, well-known side effects. Never give a dosage recommendation,
never say whether this specific combination is safe for this specific person, and always end by
telling them to ask their doctor or pharmacist before changing how they take anything. Keep it to a
short list, not an essay.`;

app.post('/api/explain-prescription', async (req, res) => {
  try {
    const { items } = req.body || {};
    if (!items || typeof items !== 'string') return res.status(400).json({ error: 'items is required' });
    if (!GEMINI_API_KEY) return res.status(500).json({ error: 'Server has no AI API key configured.' });
    const explanation = await askGemini(MEDS_SYSTEM, `Prescribed items:\n${items}`, 'explain-prescription');
    res.json({ explanation });
  } catch (err) {
    console.error('[aarogya-server] /api/explain-prescription failed:', err);
    res.status(500).json({ error: 'Could not explain this prescription right now.' });
  }
});

const REPORT_SYSTEM = `You explain lab/diagnostic reports for patients of an Indian government hospital
app, in plain, simple language. Summarise what the report is testing and what the results generally
mean, in a short list. If a value looks outside a typical reference range, say so plainly and tell
them to discuss it with their doctor — do not diagnose a condition or say they do or don't have
something. If you genuinely cannot read the image clearly, say so honestly instead of guessing.
Always end with a one-line reminder that this is general information, not a diagnosis.`;

app.post('/api/explain-report', async (req, res) => {
  try {
    const { imageBase64, mimeType } = req.body || {};
    if (!imageBase64 || !mimeType) return res.status(400).json({ error: 'imageBase64 and mimeType are required' });
    if (!GEMINI_API_KEY) return res.status(500).json({ error: 'Server has no AI API key configured.' });
    const block = mimeType === 'application/pdf'
      ? { type: 'document', source: { type: 'base64', media_type: mimeType, data: imageBase64 } }
      : { type: 'image', source: { type: 'base64', media_type: mimeType, data: imageBase64 } };
    const explanation = await askGemini(
      REPORT_SYSTEM,
      [block, { type: 'text', text: 'Please explain this report in plain language.' }],
      'explain-report'
    );
    res.json({ explanation });
  } catch (err) {
    console.error('[aarogya-server] /api/explain-report failed:', err);
    res.status(500).json({ error: 'Could not read this report right now.' });
  }
});

const PRESCRIPTION_EXTRACT_SYSTEM = `Read the supplied prescription page images and OCR text and identify only medicine names that are visibly written. OCR may misread handwriting: treat OCR text only as a clue and verify it against the images. Do not guess or invent names, strengths, or instructions. Return JSON only with this shape: {"medicines":[{"name":"visible medicine name","strength":"visible strength or empty string","instructions":"visible directions or empty string","confidence":"high|medium|low"}]}. If a line cannot be read reliably, omit it. Do not interpret the prescription, recommend treatment, or change instructions.`;

async function runPaddleOcr(images) {
  try {
    const response = await fetch(PADDLE_OCR_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(Math.max(5000, Number(PADDLE_OCR_TIMEOUT_MS) || 60000)),
      body: JSON.stringify({ images }),
    });
    if (!response.ok) return '';
    const result = await response.json();
    return Array.isArray(result.pages)
      ? result.pages.map((page, index) => `Page ${index + 1}:\n${String(page.text || '').slice(0, 8000)}`).join('\n\n').slice(0, 24000)
      : '';
  } catch {
    // PaddleOCR is an enhancement; Qwen can still inspect the original images.
    return '';
  }
}

app.post('/api/extract-prescription', async (req, res) => {
  try {
    const { images } = req.body || {};
    if (!Array.isArray(images) || images.length < 1 || images.length > 5) {
      return res.status(400).json({ error: 'Upload a prescription with between 1 and 5 readable pages.' });
    }
    const allowed = new Set(['image/jpeg','image/png','image/webp']);
    let totalBytes = 0;
    for (const image of images) {
      if (typeof image?.imageBase64 !== 'string' || !image.imageBase64 || !allowed.has(image.mimeType)) {
        return res.status(400).json({ error: 'Prescription pages must be JPEG, PNG, or WebP images.' });
      }
      totalBytes += image.imageBase64.length;
    }
    if (totalBytes > 22_400_000) return res.status(413).json({ error: 'The rendered prescription pages are too large. Use a smaller file.' });

    const ocrText = await runPaddleOcr(images);
    const content = [
      { type: 'text', text: `Extract medicine names from these prescription page images. Return JSON only.${ocrText ? `\n\nPaddleOCR text, which may contain recognition errors:\n${ocrText}` : ''}` },
      ...images.map(image => ({
        type: 'image_url',
        image_url: { url: `data:${image.mimeType};base64,${image.imageBase64}` },
      })),
    ];
    const headers = { 'Content-Type': 'application/json' };
    if (QWEN_VISION_API_KEY) headers.Authorization = `Bearer ${QWEN_VISION_API_KEY}`;
    let upstream;
    try {
      upstream = await fetch(`${QWEN_VISION_BASE_URL.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST',
        headers,
        signal: AbortSignal.timeout(Math.max(10000, Number(QWEN_VISION_TIMEOUT_MS) || 120000)),
        body: JSON.stringify({
          model: QWEN_VISION_MODEL,
          messages: [
            { role: 'system', content: PRESCRIPTION_EXTRACT_SYSTEM },
            { role: 'user', content },
          ],
          temperature: 0,
          max_tokens: 1200,
        }),
      });
    } catch (err) {
      const timeout = err?.name === 'TimeoutError' || err?.name === 'AbortError';
      return res.status(timeout ? 504 : 503).json({ error: timeout
        ? 'The local prescription model took too long. Try a smaller or clearer file.'
        : 'The Qwen model server is unavailable. Start the configured local model service and try again.' });
    }
    if (!upstream.ok) {
      console.error('[aarogya-server] Qwen prescription extraction returned HTTP', upstream.status);
      return res.status(502).json({ error: 'The prescription reader is unavailable right now.' });
    }
    const payload = await upstream.json();
    const raw = payload.choices?.[0]?.message?.content;
    if (typeof raw !== 'string' || !raw.trim()) throw new Error('Empty model response');
    const jsonText = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
    let parsed;
    try {
      parsed = JSON.parse(jsonText);
    } catch {
      const start = jsonText.indexOf('{'), end = jsonText.lastIndexOf('}');
      if (start < 0 || end <= start) throw new Error('Invalid structured response');
      parsed = JSON.parse(jsonText.slice(start, end + 1));
    }
    const medicines = Array.isArray(parsed.medicines) ? parsed.medicines.slice(0, 30).map(m => ({
      name: String(m?.name || '').trim().slice(0, 100),
      strength: String(m?.strength || '').trim().slice(0, 60),
      instructions: String(m?.instructions || '').trim().slice(0, 160),
      confidence: ['high','medium','low'].includes(String(m?.confidence).toLowerCase()) ? String(m.confidence).toLowerCase() : 'low',
    })).filter(m => m.name) : [];
    res.json({ medicines, review_required: true, note: 'Qwen3-VL can misread handwriting. Confirm every item with your clinician or pharmacist.' });
  } catch (err) {
    console.error('[aarogya-server] /api/extract-prescription failed:', err);
    res.status(500).json({ error: 'Could not read this prescription. Try a clearer image or enter medicines manually.' });
  }
});

const TIPS_SYSTEM = `You give short, general, safe wellness suggestions (exercise, food/diet, daily
routine) for someone using an Indian government hospital app. Tailor them lightly to whatever
activity level, diet preference and goal they give you, using foods and exercises realistic for an
Indian household. Give 2 short exercise/routine tips, 2 short food tips, and 1 general habit tip, as
a short list — not an essay. These are general wellness tips, not a treatment plan: don't address any
specific medical condition, and suggest seeing a doctor first if they mention one.`;

app.post('/api/health-tips', async (req, res) => {
  try {
    const { activityLevel = 'not specified', diet = 'not specified', goal = 'general wellness' } = req.body || {};
    if (!GEMINI_API_KEY) return res.status(500).json({ error: 'Server has no AI API key configured.' });
    const tips = await askGemini(
      TIPS_SYSTEM,
      `Activity level: ${activityLevel}\nDiet preference: ${diet}\nGoal: ${goal}`,
      'health-tips'
    );
    res.json({ tips });
  } catch (err) {
    console.error('[aarogya-server] /api/health-tips failed:', err);
    res.status(500).json({ error: 'Could not put together tips right now.' });
  }
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`[aarogya-server] listening on http://localhost:${PORT}`);
});
