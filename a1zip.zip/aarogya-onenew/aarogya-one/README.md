# Aarogya One

Government hospital management app — landing page, patient portal, and staff
portal, wired to a real Supabase backend (auth, database, realtime).

## Folder structure

```
aarogya-one/
├─ index.html          the whole app (landing page + dashboards)
├─ css/style.css        all styling
├─ js/app.js             all logic: hero animation, view transitions,
│                        Supabase auth, booking, live token, queue control,
│                        pharmacy, complaints
└─ supabase/
   ├─ schema.sql         run this once in Supabase's SQL editor
   └─ seed.sql           demo hospital/departments/doctors/medicines
```

## 1. Set up the database

In your Supabase project → **SQL Editor**:
1. Paste and run all of `supabase/schema.sql`.
2. Paste and run all of `supabase/seed.sql`.

If this project already has a database and you are repairing signup/profile
creation, run `supabase/fix-trigger.sql` once instead. It safely replaces the
auth-user trigger, grants a signed-in patient permission to insert only their
own patient profile as a fallback, and backfills existing users missing a
profile. Email remains in Supabase Auth rather than being duplicated in
`profiles`; the database assigns the profile role as `patient` and does not
trust the role supplied in signup metadata.

To add individually numbered beds to an existing project, run
`supabase/bed-tracking-migration.sql` once. It creates `hospital_beds` with
unique bed numbers per hospital and ward, available/occupied status, read
access for patients, staff-only management, and Realtime publication. It
deliberately does not generate bed numbers or individual statuses from the
older `beds` ward totals: staff should enter the hospital's real bed numbers
and current statuses in the staff portal. Wards without numbered records
continue to show their existing ward-level totals; partially registered wards
show their numbered beds and how many beds still need individual records.

Your Project URL and anon public key are already filled in at the top of
`js/app.js`:

```js
const SUPABASE_URL = "https://ikexaxyihafozukdlvyu.supabase.co";
const SUPABASE_ANON_KEY = "eyJ...";
```

If you ever rotate your anon key or move to a different Supabase project,
update those two lines.

For pill lookups and Jan Aushadhi store search, run
`supabase/medicine-finder-migration.sql` once. It creates public read-only
reference tables. The migration intentionally contains no sample entries:
load reviewed pill identifications and the current official store list,
including source and coordinates where available, before relying on results.

## 2. Run it — **don't just double-click index.html**

Opening the file directly (`file://...`) is the most likely reason things
were freezing with no error. Browsers restrict what a page opened this way
is allowed to do, and some of that silently breaks requests to Supabase.
Serve it over `http://localhost` instead — any of these work:

**Easiest (VS Code):** install the **Live Server** extension, right-click
`index.html` → *Open with Live Server*.

**No extension, with Node installed:**
```bash
npx serve .
```
then open the URL it prints (something like `http://localhost:3000`).

**With Python installed:**
```bash
python3 -m http.server 8000
```
then open `http://localhost:8000`.

## 3. Push to GitHub

```bash
cd aarogya-one
git init
git add .
git commit -m "Aarogya One: patient + staff portal, Supabase backend"
git branch -M main
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

You can then deploy it for free as a static site on **GitHub Pages**,
Vercel, or Netlify — all of which serve it over `https://`, which avoids
the `file://` problem entirely and is how you'd want it running for real
users anyway.

## What's wired up

**Patient portal:** sign up / log in, book an appointment, live token +
queue position (updates in real time), medicine availability and finder
mode with a per-account printable summary, pill lookup, Jan Aushadhi store
search, prescription scan suggestions, my prescriptions, file/check
complaints, and numbered bed availability by ward.

**Staff portal:** log in (accounts are created by an admin in Supabase, not
self-signup), queue control (call next token, mark done), register a
walk-in patient who doesn't have the app, write a prescription for the
patient currently called, pharmacy console (dispense prescriptions, edit
stock), complaints management, and numbered bed registration/status updates.

Role (`patient` / `staff` / `pharmacist` / `admin`) is read from the
`profiles` table after login and decided server-side by Postgres row-level
security — not just hidden in the frontend. If an action isn't allowed for
a role, you'll see the database's error message rather than it silently
doing nothing.

## AI features

All of these share the same small backend — see `server/README.md` for
setup. Without that server running, each of these will show a clear
connection error; nothing else in the app is affected.

- **Chat assistant** — the dog mascot in the dashboard corner opens a chat
  that helps with using the app (booking, tokens, medicines, complaints)
  and general (non-diagnostic) health questions. It knows your current
  token/appointment status without you having to repeat it. You can type,
  tap the mic icon to speak instead (Chrome/Edge support this best), tap
  the speaker icon to have replies read aloud, or tap the paperclip to
  attach a photo (a medicine packet, a visible symptom, a report) for the
  assistant to look at.
- **Prescription explainer** — in *My prescriptions*, an "Explain uses &
  side effects" button asks the AI to explain, in plain language, what
  each prescribed item is generally for and its common side effects. The
  explanation is saved to that prescription so it's only asked once.
- **Report explainer** — in *My reports*, upload a photo or PDF of a lab
  report; the AI reads it directly (no separate OCR step) and explains
  what it's testing and what the results generally mean. Files are stored
  privately in Supabase Storage, under a folder only that patient can
  access.
- **Prescription scan** — upload a prescription photo or PDF; the self-hosted Qwen3-VL model returns
  candidate medicine names for the user to review and add to their temporary
  list. The uploaded file is sent to the configured AI backend and is not
  stored by this scan route. Handwriting recognition can be wrong, so confirm
  each item with a clinician or pharmacist.
- **Health tips** — pick an activity level, diet preference and goal, and
  get a short list of general exercise, food and habit suggestions.

Every AI feature here is explicitly instructed not to diagnose and to
point to a real doctor or the Emergency tab when something sounds serious
— but none of this replaces medical advice, and that's stated in the UI
too.

Run `supabase/ai-features-migration.sql` in the SQL editor before using
the report upload or prescription-explain features — it adds the
`reports` table, a cached `explanation` column on prescriptions, and the
private Storage bucket the uploaded files live in.

## Not built yet

Teleconsultation, referral tracking, reading lab/test reports, and the
admin-level hospital dashboard — these need a couple more tables added to
`schema.sql` first.
