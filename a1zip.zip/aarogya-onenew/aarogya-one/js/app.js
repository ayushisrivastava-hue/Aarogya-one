(async()=>{
const $=s=>document.querySelector(s),cv=$('#c'),ctx=cv.getContext('2d');
document.querySelectorAll('#v3 .dcard > .feature-art').forEach(art=>{
 const content=document.createElement('div');content.className='banner-content';
 while(art.nextSibling)content.appendChild(art.nextSibling);
 art.after(content);
});
const mascot=document.createElement('button');
mascot.type='button';mascot.className='dash-mascot';mascot.setAttribute('aria-label','Care mascot: show a helpful tip');mascot.setAttribute('aria-expanded','false');
const landingDog=document.querySelector('#v1 .dog');
if(landingDog){const dogArt=landingDog.cloneNode(true);dogArt.setAttribute('aria-hidden','true');mascot.append(dogArt);}
const mascotTip=document.createElement('span');mascotTip.className='mascot-tip';mascotTip.textContent='Hi! Tap me if you need help.';mascot.append(mascotTip);$('#v3').append(mascot);
mascot.setAttribute('aria-label','Aarogya assistant: chat for help');
mascot.addEventListener('click',()=>{ toggleChat(); });
mascot.addEventListener('mouseenter',()=>{ if(!chatOpen) mascot.classList.add('is-speaking'); });
mascot.addEventListener('mouseleave',()=>{ if(!chatOpen) mascot.classList.remove('is-speaking'); });

// ---------- AI chat assistant ----------
// Points at the small backend in /server (see server/README.md). Change this
// to your deployed backend's URL once you host it; localhost only works
// while you're running the backend on your own machine.
const CHAT_API_URL = `${window.location.protocol}//${window.location.hostname}:8787/api/chat`;
let chatOpen=false, chatHistory=[], chatBusy=false, speakReplies=false, pendingAttachment=null;
const chatPanel=document.createElement('div');
chatPanel.className='chat-panel'; chatPanel.setAttribute('role','dialog'); chatPanel.setAttribute('aria-label','Aarogya assistant chat');
chatPanel.innerHTML=`
<div class="chat-head"><span>Aarogya Assistant</span>
<span class="chat-head-btns">
<button type="button" class="chat-speak" id="chatSpeakToggle" aria-pressed="false" title="Read replies aloud">&#128266;</button>
<button type="button" class="chat-close" aria-label="Close chat">&times;</button>
</span></div>
<div class="chat-log" id="chatLog"></div>
<div class="chat-attach-preview hid" id="chatAttachPreview"></div>
<form class="chat-form" id="chatForm">
<button type="button" class="chat-icon-btn" id="chatAttachBtn" title="Attach a photo" aria-label="Attach a photo">&#128206;</button>
<input type="file" id="chatAttachInput" accept="image/*" class="hid">
<input id="chatInput" autocomplete="off" placeholder="Ask about booking, medicines, your token…">
<button type="button" class="chat-icon-btn" id="chatMicBtn" title="Speak instead of typing" aria-label="Speak instead of typing">&#127908;</button>
<button type="submit" class="go">Send</button>
</form>
<p class="chat-disclaimer">This assistant helps you use the app and gives general information only — it does not diagnose, and it is not a substitute for medical care. In an emergency, use the Emergency tab.</p>`;
$('#v3').append(chatPanel);
function addChatMsg(role,text){
  const log=document.getElementById('chatLog');
  const row=document.createElement('div'); row.className='chat-msg '+role; row.textContent=text;
  log.append(row); log.scrollTop=log.scrollHeight;
  if (role==='bot' && speakReplies && 'speechSynthesis' in window && text!=='…') {
    try{ const u=new SpeechSynthesisUtterance(text); speechSynthesis.cancel(); speechSynthesis.speak(u); }catch(e){}
  }
}
function toggleChat(force){
  chatOpen = typeof force==='boolean' ? force : !chatOpen;
  chatPanel.classList.toggle('open', chatOpen);
  mascot.setAttribute('aria-expanded', String(chatOpen));
  mascot.classList.toggle('is-speaking', chatOpen);
  if (chatOpen && !chatHistory.length) {
    addChatMsg('bot', "Hi, I'm the Aarogya One assistant. Ask me how to book an appointment, check medicines, find your token, or anything else about using the app. You can type, tap the mic to speak, or attach a photo.");
  }
  if (chatOpen) document.getElementById('chatInput').focus();
  else if ('speechSynthesis' in window) speechSynthesis.cancel();
}
chatPanel.querySelector('.chat-close').onclick=()=>toggleChat(false);

// Read replies aloud, on request.
const speakBtn = chatPanel.querySelector('#chatSpeakToggle');
speakBtn.onclick = ()=>{
  speakReplies = !speakReplies;
  speakBtn.classList.toggle('on', speakReplies);
  speakBtn.setAttribute('aria-pressed', String(speakReplies));
  if (!speakReplies && 'speechSynthesis' in window) speechSynthesis.cancel();
};

// Voice input: dictate instead of typing.
const micBtn = chatPanel.querySelector('#chatMicBtn');
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SR) { micBtn.disabled = true; micBtn.title = 'Voice input is not supported in this browser'; }
else {
  const recog = new SR(); recog.lang='en-IN'; recog.interimResults=false; recog.maxAlternatives=1;
  let listening=false;
  recog.onresult = (e)=>{ document.getElementById('chatInput').value = e.results[0][0].transcript; };
  recog.onend = ()=>{ listening=false; micBtn.classList.remove('on'); };
  recog.onerror = ()=>{ listening=false; micBtn.classList.remove('on'); };
  micBtn.onclick = ()=>{
    if (listening) { recog.stop(); return; }
    try{ recog.start(); listening=true; micBtn.classList.add('on'); }catch(e){}
  };
}

// Attach a photo to the next message (a symptom photo, a prescription label, etc).
const attachBtn = chatPanel.querySelector('#chatAttachBtn');
const attachInput = chatPanel.querySelector('#chatAttachInput');
const attachPreview = chatPanel.querySelector('#chatAttachPreview');
attachBtn.onclick = ()=>attachInput.click();
attachInput.addEventListener('change', async ()=>{
  const file = attachInput.files && attachInput.files[0];
  if (!file) return;
  if (file.size > 8*1024*1024) { addChatMsg('bot','That photo is a bit large — please use one under 8MB.'); attachInput.value=''; return; }
  const base64 = await new Promise((resolve,reject)=>{ const r=new FileReader(); r.onload=()=>resolve(r.result.split(',')[1]); r.onerror=reject; r.readAsDataURL(file); });
  pendingAttachment = { imageBase64: base64, mimeType: file.type || 'image/jpeg', name: file.name };
  attachPreview.textContent = '📎 '+file.name+' — will be sent with your next message';
  attachPreview.classList.remove('hid');
});

chatPanel.querySelector('#chatForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if (chatBusy) return;
  const input=document.getElementById('chatInput');
  const text=input.value.trim();
  const attachment = pendingAttachment;
  if (!text && !attachment) return;
  input.value=''; pendingAttachment=null; attachPreview.classList.add('hid'); attachPreview.textContent='';
  addChatMsg('user', text || '(sent a photo)');
  chatHistory.push({role:'user', content:text || '(sent a photo)'});
  chatBusy=true;
  addChatMsg('bot','…');
  const log=document.getElementById('chatLog');
  // Ground the assistant in what's actually on screen right now, so it doesn't have to guess.
  let liveContext = null;
  if (typeof currentAppt !== 'undefined' && currentAppt) {
    liveContext = `Patient's current appointment: token #${currentAppt.token_no ?? '—'}, doctor ${currentAppt.doctors?.name ?? ''}, status ${currentAppt.status}.`;
  }
  try{
    const res = await fetch(CHAT_API_URL, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        message: text || 'Please look at the attached photo.',
        history: chatHistory.slice(-10),
        role: (typeof myRole!=='undefined'?myRole:null),
        context: liveContext,
        attachment: attachment ? { imageBase64: attachment.imageBase64, mimeType: attachment.mimeType } : null,
      })
    });
    log.lastChild.remove();
    if (!res.ok) throw new Error('Assistant is unavailable right now (status '+res.status+').');
    const data = await res.json();
    addChatMsg('bot', data.reply || "Sorry, I didn't get a response.");
    chatHistory.push({role:'assistant', content:data.reply||''});
  } catch(err){
    log.lastChild.remove();
    addChatMsg('bot', "I can't reach the assistant backend right now. Make sure the server in /server is running (see server/README.md). ("+(err?.message||err)+")");
  } finally { chatBusy=false; }
});
document.querySelectorAll('#v3 .banner-content > label').forEach(label=>{
 const control=label.nextElementSibling;
 if(!control||!['INPUT','SELECT','TEXTAREA'].includes(control.tagName))return;
 const field=document.createElement('div');field.className='field-pair';
 label.before(field);field.append(label,control);
});
try{await document.fonts.load('700 100px Poppins')}catch(e){}
const dpr=Math.min(window.devicePixelRatio||1,2);
let base,disp,data,w,h,R,parts=[];
function build(){
 const cs=getComputedStyle(document.documentElement),ink=cs.getPropertyValue('--ink').trim(),ac=cs.getPropertyValue('--ac').trim();
 w=Math.min(innerWidth-32-(innerWidth>560?170:0),900);const size=Math.min(w/6.6,110);h=Math.round(size*1.5);
 cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);cv.style.width=w+'px';cv.style.height=h+'px';R=size*0.55;parts=[];
 base=document.createElement('canvas');base.width=cv.width;base.height=cv.height;
 const b=base.getContext('2d');b.scale(dpr,dpr);b.font='700 '+size+'px Poppins,sans-serif';b.textBaseline='middle';
 const a='Aarogya ',o='One',wa=b.measureText(a).width,wo=b.measureText(o).width,x=(w-wa-wo)/2;
 b.fillStyle=ink;b.fillText(a,x,h/2);b.fillStyle=ac;b.fillText(o,x+wa,h/2);
 data=b.getImageData(0,0,cv.width,cv.height).data;
 disp=document.createElement('canvas');disp.width=cv.width;disp.height=cv.height;disp.getContext('2d').drawImage(base,0,0);
}
function punch(x,y){
 const d=disp.getContext('2d');d.save();d.globalCompositeOperation='destination-out';
 const g=d.createRadialGradient(x*dpr,y*dpr,0,x*dpr,y*dpr,R*dpr);g.addColorStop(0,'rgba(0,0,0,.9)');g.addColorStop(1,'rgba(0,0,0,0)');
 d.fillStyle=g;d.beginPath();d.arc(x*dpr,y*dpr,R*dpr,0,7);d.fill();d.restore();
 for(let i=0;i<45&&parts.length<6000;i++){const an=Math.random()*6.283,r=Math.random()*R,px=x+Math.cos(an)*r,py=y+Math.sin(an)*r,ix=Math.floor(px*dpr),iy=Math.floor(py*dpr);
  if(ix<0||iy<0||ix>=cv.width||iy>=cv.height)continue;const k=(iy*cv.width+ix)*4;
  if(data[k+3]>100)parts.push({x:px,y:py,vx:Math.cos(an)*(1+Math.random()*2.5)+1.2,vy:Math.sin(an)*(1+Math.random()*2.5)-.3,l:60+Math.random()*60,c:'rgb('+data[k]+','+data[k+1]+','+data[k+2]+')',s:1.5+Math.random()*2})}
}
function frame(){
 const d=disp.getContext('2d');d.globalAlpha=0.035;d.drawImage(base,0,0);d.globalAlpha=1;
 ctx.clearRect(0,0,cv.width,cv.height);ctx.drawImage(disp,0,0);ctx.save();ctx.scale(dpr,dpr);parts=parts.filter(p=>p.l>0);
 parts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.vx*=.985;p.vy=p.vy*.985+.015;p.l--;ctx.globalAlpha=Math.min(1,p.l/40);ctx.fillStyle=p.c;ctx.fillRect(p.x,p.y,p.s,p.s)});
 ctx.restore();requestAnimationFrame(frame);
}
build();frame();
cv.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect();punch(e.clientX-r.left,e.clientY-r.top)});
if(!matchMedia('(prefers-reduced-motion: reduce)').matches)setTimeout(()=>{const s=performance.now();(function sw(n){const k=(n-s)/2400;if(k<1){punch(w*(0.1+0.8*k),h/2+Math.sin(k*9)*h*0.12);requestAnimationFrame(sw)}})(s)},700);
let rt;addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(build,200)});
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',build);
const v1=$('#v1'),v2=$('#v2'),ov=$('#ov');let cur=null,from=null;
{
const st=document.querySelector('.story'),pns=[...st.querySelectorAll('.pn')],typed=$('.typing-text');
if('IntersectionObserver' in window){
 st.classList.add('has-reveal');
 const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
  if(!entry.isIntersecting){entry.target.classList.remove('visible');return}
  entry.target.classList.add('visible');
  if(entry.target.contains(typed)&&!typed.dataset.started){
   typed.dataset.started='true';
   const full=entry.target.querySelector('.typewriter').getAttribute('aria-label');
   if(matchMedia('(prefers-reduced-motion: reduce)').matches){typed.textContent=full;typed.dataset.done='true';return}
   typed.textContent='';
   let index=0;
   const timer=setInterval(()=>{typed.textContent=full.slice(0,++index);if(index>=full.length){typed.dataset.done='true';clearInterval(timer)}},38);
  }
  revealObserver.unobserve(entry.target);
 }),{root:v1,threshold:.18});
 pns.forEach(panel=>revealObserver.observe(panel));
}else{
 pns.forEach(panel=>panel.classList.add('visible'));
}
const featureRow=$('.wr'),featureCards=[...featureRow.children];
const track=document.createElement('div');track.className='feature-track';
featureCards.forEach(card=>track.appendChild(card));
featureCards.forEach(card=>{const clone=card.cloneNode(true);clone.setAttribute('aria-hidden','true');clone.inert=true;track.appendChild(clone)});
featureRow.appendChild(track);
let slowTimer;
featureRow.addEventListener('click',event=>{
 if(!event.target.closest('.f'))return;
 featureRow.classList.add('slow');
 clearTimeout(slowTimer);
 slowTimer=setTimeout(()=>featureRow.classList.remove('slow'),5000);
});
}
const start=()=>{v1.classList.add('out');v2.classList.remove('off');setTimeout(()=>$('#t2').focus(),500)};$('#go').onclick=start;$('#go2').onclick=start;$('#more-b').onclick=()=>$('#more').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
$('#bk').onclick=()=>{v1.classList.remove('out');v2.classList.add('off');$('#go').focus()};
function setBox(r,rad){ov.style.left=r.left+'px';ov.style.top=r.top+'px';ov.style.width=r.width+'px';ov.style.height=r.height+'px'}
document.querySelectorAll('.card').forEach(c=>c.onclick=()=>{
 from=c;cur=$('#'+c.dataset.p);const r=c.getBoundingClientRect();
 ov.className=c.classList.contains('pt')?'op':'os';ov.hidden=false;setBox(r);ov.offsetWidth;
 ov.classList.add('full');setBox({left:0,top:0,width:innerWidth,height:innerHeight});
 setTimeout(()=>{cur.hidden=false;const f=cur.querySelector('input');if(f)f.focus()},750);
});
function closeP(){
 if(!cur)return;cur.hidden=true;ov.classList.remove('full');setBox(from.getBoundingClientRect());
 setTimeout(()=>{ov.hidden=true;from.focus();cur=null},760);
}
document.querySelectorAll('[data-x]').forEach(b=>b.onclick=closeP);
addEventListener('keydown',e=>{if(e.key==='Escape'){closeP();$('#emg').hidden=true}});

// ---------- Real Supabase wiring ----------
const SUPABASE_URL = "https://ikexaxyihafozukdlvyu.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlrZXhheHlpaGFmb3p1a2Rsdnl1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3MDg4ODQsImV4cCI6MjEwNzI4NDg4NH0.Q45gFoK1MjAh8cBR_BUz9bmOPj2X2nL4uhTqW3VNm3c";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
window.addEventListener('error', (e)=>{ const b=document.getElementById('globalErr'); if(b){ b.textContent='Error: '+e.message; b.hidden=false; } });
window.addEventListener('unhandledrejection', (e)=>{ const b=document.getElementById('globalErr'); if(b){ b.textContent='Error: '+(e.reason?.message||e.reason); b.hidden=false; } });
function withTimeout(promise, ms=12000, label='request'){
  return Promise.race([
    promise,
    new Promise((_,rej)=>setTimeout(()=>rej(new Error('Timed out waiting for '+label+'. Check your internet connection, and check in Supabase whether this project is paused (free projects pause after a period of no use — open the Supabase dashboard, it will show a Restore/Resume button if so).')), ms))
  ]);
}
let myRole = null, currentUser = null, queueChannel = null, tokenChannel = null, currentAppt = null;

function setMsg(id, text, ok){ const el=document.getElementById(id); if(!el) return; el.textContent=text||''; el.style.color = text ? (ok? '#2E8B57':'#D64545') : ''; }

// Top nav
function closeDash(){ $('#v3').classList.add('off'); if(queueChannel){sb.removeChannel(queueChannel);queueChannel=null} if(tokenChannel){sb.removeChannel(tokenChannel);tokenChannel=null} }
function goHome(){ closeDash(); v2.classList.add('off'); if(!ov.hidden) closeP(); v1.classList.remove('out'); }
$('#tnHome').onclick = ()=>{ goHome(); start(); };
$('#tnAbout').onclick = ()=>{ goHome(); setTimeout(()=>$('#more').scrollIntoView({behavior:'smooth'}),10); };
$('#tnLogout').onclick = async ()=>{ await sb.auth.signOut(); goHome(); v1.classList.remove('out'); };
$('#tnEmg').onclick = ()=>{ $('#emg').hidden=false; };
$('#emgClose').onclick = ()=>{ $('#emg').hidden=true; };
$('#ctaEmg').onclick = ()=>{ $('#emg').hidden=false; };
$('#dashEmergency').onclick = ()=>{ $('#emg').hidden=false; };
$('#emg').addEventListener('click',event=>{if(event.target===$('#emg'))$('#emg').hidden=true});

// Patient auth tabs
document.querySelectorAll('.atab').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('.atab').forEach(x=>x.classList.remove('on')); b.classList.add('on');
  $('#ptSignup').classList.toggle('hid', b.dataset.at!=='su');
  $('#ptLogin').classList.toggle('hid', b.dataset.at!=='li');
});

$('#ptSignup').addEventListener('submit', async (e)=>{
  e.preventDefault(); setMsg('suMsg','',true);
  const btn=e.target.querySelector('button'); btn.disabled=true;
  const email=$('#suEmail').value.trim(), password=$('#suPass').value;
  const fullName=$('#suName').value.trim(), mobile=$('#suMobile').value.trim();
  try {
    const { data, error } = await withTimeout(sb.auth.signUp({
      email, password,
      options:{ data:{ full_name:fullName, mobile, role:'patient' } }
    }), 12000, 'sign up');
    if(error){ setMsg('suMsg', error.message, false); return; }

    if(data.session && data.user){
      const {error:profileError}=await withTimeout(sb.from('profiles').upsert({
        id:data.user.id, full_name:fullName, mobile
      },{onConflict:'id'}),12000,'profile setup');
      if(profileError){
        setMsg('suMsg','Your account was created, but profile setup failed: '+profileError.message+' Run supabase/fix-trigger.sql in the Supabase SQL Editor, then log in again.',false);
        return;
      }
      setMsg('suMsg','Account created. Signing you in…',true);
      return;
    }

    $('[data-at="li"]').click();
    $('#liEmail').value=email;
    $('#liPass').value='';
    setMsg('liMsg','Account created. Confirm your email if requested, then log in.',true);
  } catch(err){
    const message=err?.message||String(err);
    setMsg('suMsg','Could not complete signup: '+message,false);
  }
  finally { btn.disabled=false; }
});

$('#ptLogin').addEventListener('submit', async (e)=>{
  e.preventDefault(); setMsg('liMsg','',true);
  const btn=e.target.querySelector('button'); btn.disabled=true;
  try {
    const { error } = await withTimeout(sb.auth.signInWithPassword({ email:$('#liEmail').value.trim(), password:$('#liPass').value }), 12000, 'login');
    if(error){ setMsg('liMsg', error.message, false); return; }
    setMsg('liMsg','Signed in…', true);
  } catch(err){ setMsg('liMsg', 'Could not reach Supabase: '+(err?.message||err), false); }
  finally { btn.disabled=false; }
});

$('#stLogin').addEventListener('submit', async (e)=>{
  e.preventDefault(); setMsg('stMsg','',true);
  const btn=e.target.querySelector('button'); btn.disabled=true;
  try {
    const { error } = await withTimeout(sb.auth.signInWithPassword({ email:$('#stEmail').value.trim(), password:$('#stPass').value }), 12000, 'login');
    if(error){ setMsg('stMsg', error.message, false); return; }
    setMsg('stMsg','Signed in…', true);
  } catch(err){ setMsg('stMsg', 'Could not reach Supabase: '+(err?.message||err), false); }
  finally { btn.disabled=false; }
});

async function handleAuthSession(session){
  currentUser = session ? session.user : null;
  if (!currentUser) { myRole=null; $('#tnLogout').classList.add('hid'); return; }
  const userId=currentUser.id;
  let prof, error;
  try { ({ data: prof, error } = await withTimeout(sb.from('profiles').select('role,full_name,health_id').eq('id', userId).single(), 12000, 'profile lookup')); }
  catch(e){ error=e; }
  if(!currentUser || currentUser.id!==userId)return;
  if (error) {
    if(!ov.hidden) closeP();
    v1.classList.add('out'); v2.classList.add('off'); $('#v3').classList.remove('off');
    $('#dashPatient').classList.add('hid'); $('#dashStaff').classList.add('hid');
    $('#dashTitle').textContent='Profile setup needs attention';
    let notice=$('#authProfileError');
    if(!notice){
      notice=document.createElement('div');
      notice.id='authProfileError';
      notice.className='dcard auth-profile-error';
      document.querySelector('#v3 .dash').appendChild(notice);
    }
    notice.textContent='Signed in, but your profile could not be loaded: '+error.message+' Run supabase/fix-trigger.sql in the Supabase SQL Editor, then sign out and log in again.';
    return;
  }
  const staleNotice=$('#authProfileError');if(staleNotice)staleNotice.remove();
  myRole = prof.role;
  $('#tnLogout').classList.remove('hid');
  if(!ov.hidden) closeP();
  v1.classList.add('out'); v2.classList.add('off'); $('#v3').classList.remove('off');
  $('#dashPatient').classList.toggle('hid', myRole!=='patient');
  $('#dashStaff').classList.toggle('hid', myRole==='patient');
  const title=$('#dashTitle');
  const greeting=document.createElement('span');
  greeting.className='greeting-prefix';
  greeting.textContent='Welcome back,';
  const name=document.createElement('span');
  name.className='greeting-name';
  name.textContent=prof.full_name||(myRole==='patient'?'there':'team');
  title.replaceChildren(greeting,name);
  if (myRole==='patient'){ loadHospitals(); loadToken(); loadMedHospitals(); loadMyRx(); loadBedHospitals(); loadReports(); }
  else { loadQueueDoctors(); loadPharmacy(); loadStockHospitals(); loadStaffComplaints(); loadWalkinDepts(); loadSBedHospitals(); }
}
sb.auth.onAuthStateChange((_event, session)=>{
  currentUser=session?session.user:null;
  if(!currentUser){myRole=null;$('#tnLogout').classList.add('hid');return}
  setTimeout(()=>handleAuthSession(session),0);
});

// ---------- Patient: booking ----------
async function loadHospitals(){
  const { data, error } = await sb.from('hospitals').select('id,name').order('name');
  if (error) { setMsg('bookMsg', error.message, false); return; }
  $('#selHospital').innerHTML = data.map(h=>`<option value="${h.id}">${h.name}</option>`).join('');
  loadDepts();
}
$('#selHospital').onchange = loadDepts;
async function loadDepts(){
  const hid = $('#selHospital').value;
  const { data, error } = await sb.from('departments').select('id,name').eq('hospital_id', hid).order('name');
  if (error) { setMsg('bookMsg', error.message, false); return; }
  $('#selDept').innerHTML = data.map(d=>`<option value="${d.id}">${d.name}</option>`).join('');
  loadDoctors();
}
$('#selDept').onchange = loadDoctors;
async function loadDoctors(){
  const did = $('#selDept').value;
  const { data, error } = await sb.from('doctors').select('id,name,available').eq('department_id', did).order('name');
  if (error) { setMsg('bookMsg', error.message, false); return; }
  $('#selDoctor').innerHTML = data.map(d=>`<option value="${d.id}" ${d.available?'':'disabled'}>${d.name}${d.available?'':' (unavailable)'}</option>`).join('');
}
$('#btnBook').onclick = async ()=>{
  setMsg('bookMsg','',true);
  const doctor_id=$('#selDoctor').value, department_id=$('#selDept').value;
  if(!doctor_id||!department_id){ setMsg('bookMsg','Pick a department and doctor first.', false); return; }
  $('#btnBook').disabled=true;
  const { error } = await sb.from('appointments').insert({ patient_id:currentUser.id, doctor_id, department_id });
  $('#btnBook').disabled=false;
  if(error){ setMsg('bookMsg', error.message, false); return; }
  setMsg('bookMsg','Booked!', true);
  loadToken();
};

// ---------- Patient: live token ----------
async function loadToken(){
  setMsg('tokenMsg','',true);
  $('#tokenBody').innerHTML = 'Loading…';
  const today = new Date().toISOString().slice(0,10);
  const { data, error } = await sb.from('appointments')
    .select('id,token_no,status,doctor_id,doctors(name),departments(name)')
    .eq('patient_id', currentUser.id).gte('slot_time', today)
    .order('created_at', { ascending:false }).limit(1);
  if (error) { setMsg('tokenMsg', error.message, false); return; }
  if (!data.length) { $('#tokenBody').innerHTML = "<p class='hint2'>No appointment booked today yet.</p>"; return; }
  currentAppt = data[0];
  renderToken(currentAppt);
  if (tokenChannel) sb.removeChannel(tokenChannel);
  tokenChannel = sb.channel('tok-'+currentAppt.doctor_id)
    .on('postgres_changes', { event:'*', schema:'public', table:'appointments', filter:`doctor_id=eq.${currentAppt.doctor_id}` }, ()=>loadToken())
    .subscribe();
}
function renderToken(a){
  const tokenBody=$('#tokenBody'),previous=tokenBody.dataset.tokenNumber;
  $('#tokenBody').innerHTML = `
    <div class="tokbig"><div class="n">${a.token_no ?? '—'}</div><div class="lb">your token number</div></div>
    <div class="drow"><span class="k">Doctor</span><span>${a.doctors?.name ?? ''}</span></div>
    <div class="drow"><span class="k">Department</span><span>${a.departments?.name ?? ''}</span></div>
    <div class="drow"><span class="k">Status</span><span class="pill ${a.status}">${a.status}</span></div>
    <div class="drow"><span class="k">Patients ahead of you</span><span id="aheadCount">…</span></div>
    <div id="etaRow"></div>`;
  tokenBody.dataset.tokenNumber=String(a.token_no ?? '');
  if(previous!==undefined&&previous!==tokenBody.dataset.tokenNumber){
    const number=tokenBody.querySelector('.tokbig .n');
    number.classList.remove('token-updated');void number.offsetWidth;number.classList.add('token-updated');
  }
  refreshAhead(a);
  renderTokenETA(a);
}
async function refreshAhead(a){
  const el=document.getElementById('aheadCount'); if(!el) return;
  if (a.status!=='waiting' || a.token_no==null){ el.textContent = a.status==='called' ? "you're up" : '—'; return; }
  const today = new Date().toISOString().slice(0,10);
  const { count, error } = await sb.from('appointments')
    .select('id',{count:'exact',head:true}).eq('doctor_id',a.doctor_id).eq('status','waiting')
    .gte('slot_time', today).lt('token_no', a.token_no);
  if (!error) el.textContent = count;
}
// Expected arrival time — shown on the token card and updates every time the queue moves.
// avg_consult_minutes is a column on the doctors table (default 7 min; set per-doctor in DB).
async function renderTokenETA(a){
  const etaEl=document.getElementById('etaRow'); if(!etaEl) return;
  if(a.status!=='waiting'||a.token_no==null){ etaEl.innerHTML=''; return; }
  const today=new Date().toISOString().slice(0,10);
  const [{ count }, { data: docRow }]=await Promise.all([
    sb.from('appointments').select('id',{count:'exact',head:true})
      .eq('doctor_id',a.doctor_id).eq('status','waiting').gte('slot_time',today).lt('token_no',a.token_no),
    sb.from('doctors').select('avg_consult_minutes').eq('id',a.doctor_id).single()
  ]);
  const avgMin=docRow?.avg_consult_minutes??7;
  const waitMin=(count??0)*avgMin;
  const eta=new Date(Date.now()+waitMin*60000);
  const timeStr=eta.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',hour12:true});
  etaEl.innerHTML=`<div class="drow eta-row"><span class="k">⏰ Arrive by</span><span class="eta-time">${timeStr}</span><small class="eta-sub">&nbsp;(~${waitMin} min · ${count??0} ahead)</small></div>`;
}

  tokenBody.dataset.tokenNumber=String(a.token_no ?? '');
  if(previous!==undefined&&previous!==tokenBody.dataset.tokenNumber){
    const number=tokenBody.querySelector('.tokbig .n');
    number.classList.remove('token-updated');void number.offsetWidth;number.classList.add('token-updated');
  }
  refreshAhead(a);
}
async function refreshAhead(a){
  const el=document.getElementById('aheadCount'); if(!el) return;
  if (a.status!=='waiting' || a.token_no==null){ el.textContent = a.status==='called' ? "you're up" : '—'; return; }
  const today = new Date().toISOString().slice(0,10);
  const { count, error } = await sb.from('appointments')
    .select('id',{count:'exact',head:true}).eq('doctor_id',a.doctor_id).eq('status','waiting')
    .gte('slot_time', today).lt('token_no', a.token_no);
  if (!error) el.textContent = count;
}

// ---------- Staff: queue control ----------
async function loadQueueDoctors(){
  const { data, error } = await sb.from('doctors').select('id,name,departments(name)').order('name');
  if (error) { setMsg('queueMsg', error.message, false); return; }
  $('#selQueueDoctor').innerHTML = data.map(d=>`<option value="${d.id}">${d.name} — ${d.departments?.name ?? ''}</option>`).join('');
  loadQueue();
  refreshRxApptOptions();
}
$('#selQueueDoctor').onchange = ()=>{ loadQueue(); refreshRxApptOptions(); };
async function loadQueue(){
  const doctor_id = $('#selQueueDoctor').value;
  if(!doctor_id) return;
  setMsg('queueMsg','',true);
  const today = new Date().toISOString().slice(0,10);
  const { data, error } = await sb.from('appointments')
    .select('id,token_no,status,walk_in_name,profiles(full_name)')
    .eq('doctor_id', doctor_id).gte('slot_time', today).in('status',['waiting','called'])
    .order('token_no',{ascending:true});
  if (error) { setMsg('queueMsg', error.message, false); return; }
  const waitingCount=data.filter(a=>a.status==='waiting').length;
  const summary=$('#queueSummary'),previous=summary.dataset.waiting;
  summary.innerHTML=`<strong>${waitingCount}</strong><span>waiting for care</span><i>${data.filter(a=>a.status==='called').length} currently called</i>`;
  if(previous!==undefined&&previous!==String(waitingCount)){
    summary.classList.remove('queue-updated');void summary.offsetWidth;summary.classList.add('queue-updated');
  }
  summary.dataset.waiting=String(waitingCount);
  $('#queueList').innerHTML = data.length ? data.map(a=>`
    <div class="qrow"><span>#${a.token_no} — ${a.profiles?.full_name || a.walk_in_name || 'Patient'} <span class="pill ${a.status}">${a.status}</span></span>
    <span>${a.status==='called' ? `<button data-done="${a.id}">Mark done</button>` : ''}</span></div>`).join('')
    : "<p class='hint2'>No one waiting right now.</p>";
  document.querySelectorAll('[data-done]').forEach(b=>b.onclick=async ()=>{
    await sb.from('appointments').update({status:'done'}).eq('id', b.dataset.done); loadQueue();
  });
  if (queueChannel) sb.removeChannel(queueChannel);
  queueChannel = sb.channel('q-'+doctor_id)
    .on('postgres_changes',{event:'*',schema:'public',table:'appointments',filter:`doctor_id=eq.${doctor_id}`}, loadQueue)
    .subscribe();  refreshRxApptOptions();
}
$('#btnCallNext').onclick = async ()=>{
  const doctor_id = $('#selQueueDoctor').value;
  const today = new Date().toISOString().slice(0,10);
  const { data, error } = await sb.from('appointments')
    .select('id,token_no').eq('doctor_id',doctor_id).eq('status','waiting')
    .gte('slot_time', today).order('token_no',{ascending:true}).limit(1);
  if (error) { setMsg('queueMsg', error.message, false); return; }
  if (!data.length) { setMsg('queueMsg','No one waiting.', true); return; }
  await sb.from('appointments').update({status:'called'}).eq('id', data[0].id);
  setMsg('queueMsg', 'Called token #'+data[0].token_no, true);
  loadQueue();
};

// ---------- Dashboard tab switching ----------
document.querySelectorAll('.dtab').forEach(b=>b.onclick=()=>{
  const group = b.closest('section');
  group.querySelectorAll('.dtab').forEach(x=>{
    const active=x.dataset.dt===b.dataset.dt;
    x.classList.toggle('on',active);
    if(active)x.setAttribute('aria-current','page');
    else x.removeAttribute('aria-current');
  });
  group.querySelectorAll('.dpanel').forEach(p=>p.classList.add('hid'));
  document.getElementById(b.dataset.dt).classList.remove('hid');
});

// ---------- Patient: medicines ----------
async function loadMedHospitals(){
  loadMedicineSummary();
  const { data, error } = await sb.from('hospitals').select('id,name').order('name');
  if (error) { setMsg('medsMsg', error.message, false); return; }
  $('#selMedHospital').innerHTML = data.map(h=>`<option value="${h.id}">${h.name}</option>`).join('');
  loadMedicines();
}
$('#selMedHospital').onchange = loadMedicines;
$('#medSearch').addEventListener('input', ()=>{ clearTimeout(window._mt); window._mt=setTimeout(loadMedicines, 250); });
async function loadMedicines(){
  const hid = $('#selMedHospital').value; if(!hid) return;
  let q = sb.from('medicines').select('id,name,quantity,low_stock_level').eq('hospital_id', hid).order('name');
  const term = $('#medSearch').value.trim();
  if (term) q = q.ilike('name', '%'+term+'%');
  let { data, error } = await q;
  if (error) { setMsg('medsMsg', error.message, false); return; }
  let fuzzy=false;
  if(term.length>=3&&!data.length){
    const all=await sb.from('medicines').select('id,name,quantity,low_stock_level').eq('hospital_id',hid).order('name').limit(500);
    if(!all.error){const needle=term.toLowerCase().replace(/[^a-z0-9]/g,'');data=all.data.map(m=>({...m,score:medicineNameSimilarity(needle,m.name)})).filter(m=>m.score>=0.62).sort((a,b)=>b.score-a.score).slice(0,12);fuzzy=data.length>0;}
  }
  if(fuzzy)$('#medsMsg').textContent='No exact match. Showing possible spelling matches; confirm the medicine name.';
  $('#medsList').innerHTML = data.length ? data.map(m=>{
    const state = m.quantity<=0 ? ['Out of stock','#D64545'] : (m.quantity<=m.low_stock_level ? ['Low stock','#B5690A'] : ['Available','#2E8B57']);
    return `<div class="mrow"><span>${escapeHtml(m.name)}</span><span class="medicine-stock" style="color:${state[1]};font-weight:700;font-size:12px">${state[0]} (${m.quantity})</span><button type="button" class="medicine-add" data-medicine="${escapeHtml(m.name)}">Add to list</button></div>`;
  }).join('') : "<p class='hint2'>No medicines found.</p>";
  document.querySelectorAll('.medicine-add').forEach(b=>b.onclick=()=>addMedicineToSummary({name:b.dataset.medicine}));
  if(term && $('#medicineFinderMode').checked) $('#finderResults').textContent=`${data.length} matching hospital stock item${data.length===1?'':'s'}.`;
}
function medicineNameSimilarity(a,name){
  const words=String(name||'').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);let best=0;
  for(const word of words){const b=word.replace(/[^a-z0-9]/g,'');if(!b)continue;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const row=[i];for(let j=1;j<=b.length;j++)row[j]=Math.min(row[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=row;}best=Math.max(best,1-prev[b.length]/Math.max(a.length,b.length,1));}
  return best;
}

// Local, per-device medicine list. It is a planning/print aid, not a prescription.
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
let medicineSummary=[];
function medicineSummaryStorageKey(){return `aarogya-medicine-summary-v1:${currentUser?.id||'guest'}`;}
function loadMedicineSummary(){try{medicineSummary=JSON.parse(localStorage.getItem(medicineSummaryStorageKey())||'[]');if(!Array.isArray(medicineSummary))medicineSummary=[];}catch(_){medicineSummary=[];}renderMedicineSummary();}
function persistMedicineSummary(){try{localStorage.setItem(medicineSummaryStorageKey(),JSON.stringify(medicineSummary));}catch(_){setMsg('medsMsg','Could not save this list on this device.',false);}renderMedicineSummary();}
function addMedicineToSummary(item){
  const name=String(item?.name||'').trim(); if(!name)return;
  if(!medicineSummary.some(x=>x.name.toLowerCase()===name.toLowerCase()))medicineSummary.push({name,details:item.details||'',addedAt:new Date().toISOString()});
  persistMedicineSummary();
}
function renderMedicineSummary(){
  const root=$('#medicineSummary'); if(!root)return;
  root.innerHTML=medicineSummary.length?medicineSummary.map((m,i)=>`<div class="mrow"><span><b>${escapeHtml(m.name)}</b>${m.details?`<small>${escapeHtml(m.details)}</small>`:''}</span><button type="button" class="medicine-remove" data-index="${i}" aria-label="Remove ${escapeHtml(m.name)}">Remove</button></div>`).join(''):'<p class="hint2">Your list is empty. Add items from medicine search or prescription scan.</p>';
  root.querySelectorAll('.medicine-remove').forEach(b=>b.onclick=()=>{medicineSummary.splice(Number(b.dataset.index),1);persistMedicineSummary();});
}
$('#medicineFinderMode').addEventListener('change',e=>{
  $('#finderResults').textContent=e.target.checked?'Finder mode is on. Search the hospital medicine list below and add matching items.':'Finder mode is off.';
  $('#pmeds').classList.toggle('finder-on',e.target.checked);
});
$('#printMedicineSummary').onclick=()=>{
  if(!medicineSummary.length){setMsg('medsMsg','Add at least one medicine before printing.',false);return;}
  const rows=medicineSummary.map(m=>`<tr><td>${escapeHtml(m.name)}</td><td>${escapeHtml(m.details||'')}</td></tr>`).join('');
  const win=window.open('','_blank','width=760,height=800');
  if(!win){setMsg('medsMsg','Allow pop-ups to print the medicine summary.',false);return;}
  win.document.write(`<!doctype html><html><head><title>Medicine summary</title><style>body{font:16px Arial,sans-serif;color:#17202a;margin:36px}h1{font-size:24px}p{color:#555}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{border:1px solid #9aa4ad;padding:10px;text-align:left}th{background:#f1f4f6}.note{margin-top:24px;font-size:12px}</style></head><body><h1>Medicine summary</h1><p>Prepared ${new Date().toLocaleString()}</p><table><thead><tr><th>Medicine</th><th>Notes</th></tr></thead><tbody>${rows}</tbody></table><p class="note">Bring this list to your doctor or pharmacist. It is not a prescription or a recommendation to start, stop, or change medicine.</p><script>window.onload=()=>window.print()<\/script></body></html>`);
  win.document.close();
};
renderMedicineSummary();

// Public reference tables are populated from verified datasets using the SQL migration.
$('#searchPills').onclick=async()=>{
  const el=$('#pillResults');el.textContent='Searching…';
  const imprint=$('#pillImprint').value.trim(),color=$('#pillColor').value.trim(),shape=$('#pillShape').value.trim();
  if(!imprint&&!(color&&shape)){el.textContent='Enter an imprint, or both color and shape.';return;}
  let q=sb.from('pill_identifiers').select('imprint,color,shape,medicine_name,strength,form,source').limit(15);
  if(imprint)q=q.ilike('imprint',`%${imprint}%`);if(color)q=q.ilike('color',`%${color}%`);if(shape)q=q.ilike('shape',`%${shape}%`);
  const {data,error}=await q;if(error){el.textContent='Pill reference data is unavailable. Apply the medicine finder migration in Supabase.';return;}
  el.innerHTML=data.length?data.map(x=>`<div class="mrow"><span><b>${escapeHtml(x.medicine_name)}</b> ${escapeHtml(x.strength||'')} ${escapeHtml(x.form||'')}<small>${escapeHtml(x.imprint)} · ${escapeHtml(x.color)} · ${escapeHtml(x.shape)} · Source: ${escapeHtml(x.source)}</small></span></div>`).join(''):'No matching pill in the reference data. Ask a pharmacist to identify it.';
};
function distanceKm(a,b){const rad=x=>x*Math.PI/180,dLat=rad(b.lat-a.lat),dLng=rad(b.lng-a.lng),v=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLng/2)**2;return 6371*2*Math.atan2(Math.sqrt(v),Math.sqrt(1-v));}
async function findStores(coords=null){
  const out=$('#storeResults'),city=$('#storeCity').value.trim();out.textContent='Searching…';
  let q=sb.from('janaushadhi_stores').select('name,address,city,state,pincode,phone,latitude,longitude,source').limit(1000);
  if(city&&!coords)q=q.ilike('city',`%${city}%`);
  if(coords)q=q.gte('latitude',coords.lat-2).lte('latitude',coords.lat+2).gte('longitude',coords.lng-2).lte('longitude',coords.lng+2);
  const {data,error}=await q;if(error){out.textContent='Store data is unavailable. Apply the medicine finder migration and load verified store records.';return;}
  let rows=data||[];
  if(coords)rows=rows.filter(x=>Number.isFinite(Number(x.latitude))&&Number.isFinite(Number(x.longitude))).map(x=>({...x,distance:distanceKm(coords,{lat:Number(x.latitude),lng:Number(x.longitude)})})).sort((a,b)=>a.distance-b.distance).slice(0,20);
  else rows=rows.slice(0,20);
  out.innerHTML=rows.length?rows.map(x=>`<div class="mrow"><span><b>${escapeHtml(x.name)}</b><small>${escapeHtml([x.address,x.city,x.state,x.pincode].filter(Boolean).join(', '))}${x.distance!=null?` · ${x.distance.toFixed(1)} km`:''}${x.phone?` · ${escapeHtml(x.phone)}`:''}</small></span></div>`).join(''):'No store records found. Check the official Jan Aushadhi locator.';
}
$('#searchStores').onclick=()=>findStores();
$('#storeCity').addEventListener('keydown',e=>{if(e.key==='Enter')findStores();});
$('#nearbyStores').onclick=()=>{if(!navigator.geolocation){$('#storeResults').textContent='Location is not supported in this browser.';return;}$('#storeResults').textContent='Getting your location…';navigator.geolocation.getCurrentPosition(p=>findStores({lat:p.coords.latitude,lng:p.coords.longitude}),()=>{$('#storeResults').textContent='Location permission was unavailable. Search by city instead.';},{enableHighAccuracy:false,timeout:10000});};

$('#scanPrescription').onclick=async()=>{
  const input=$('#prescriptionFile'),file=input.files?.[0],btn=$('#scanPrescription');
  $('#prescriptionCandidates').innerHTML='';setMsg('rxScanMsg','',true);
  if(!file){setMsg('rxScanMsg','Choose an image or PDF first.',false);return;}
  if(file.size>8*1024*1024){setMsg('rxScanMsg','Choose a file smaller than 8MB.',false);return;}
  if(!(file.type.startsWith('image/')||file.type==='application/pdf')){setMsg('rxScanMsg','Choose a prescription image or PDF.',false);return;}
  btn.disabled=true;btn.textContent='Reading prescription…';
  try{
    const images=await prescriptionFileToImages(file);
    const res=await fetch(CHAT_API_URL.replace('/api/chat','/api/extract-prescription'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({images})});
    const result=await res.json();if(!res.ok)throw new Error(result.error||'Could not read this prescription.');
    const candidates=Array.isArray(result.medicines)?result.medicines:[];
    if(!candidates.length){setMsg('rxScanMsg','No medicine names could be read. Try a clearer image or type the medicine name in search.',false);return;}
    setMsg('rxScanMsg','Review each detected name. Nothing is added until you choose it.',true);
    $('#prescriptionCandidates').innerHTML=candidates.map((m,i)=>`<div class="mrow"><span><b>${escapeHtml(m.name)}</b><small>${escapeHtml(m.strength||'')}${m.instructions?` · ${escapeHtml(m.instructions)}`:''}${m.confidence?` · ${escapeHtml(m.confidence)} confidence`:''}</small></span><button type="button" class="medicine-add" data-candidate="${i}">Add</button></div>`).join('');
    $('#prescriptionCandidates').querySelectorAll('[data-candidate]').forEach(b=>b.onclick=()=>{const m=candidates[Number(b.dataset.candidate)];addMedicineToSummary({name:m.name,details:[m.strength,m.instructions].filter(Boolean).join(' · ')});b.textContent='Added';b.disabled=true;});
  }catch(err){setMsg('rxScanMsg',err.message||'Prescription scan failed.',false);}
  finally{btn.disabled=false;btn.textContent='Read prescription';}
};

async function prescriptionFileToImages(file){
  const maxPages=5, images=[];
  if(file.type==='application/pdf'){
    const pdfjs=await import('https://cdn.jsdelivr.net/npm/pdfjs-dist@6.4.299/build/pdf.mjs');
    pdfjs.GlobalWorkerOptions.workerSrc='https://cdn.jsdelivr.net/npm/pdfjs-dist@6.4.299/build/pdf.worker.mjs';
    const pdf=await pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer())}).promise;
    if(pdf.numPages>maxPages)throw new Error(`This scan supports up to ${maxPages} PDF pages. Split the prescription and upload the relevant pages.`);
    for(let pageNo=1;pageNo<=pdf.numPages;pageNo++){
      const page=await pdf.getPage(pageNo),base=page.getViewport({scale:1}),scale=Math.min(1.6,1600/base.width),viewport=page.getViewport({scale});
      const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
      await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;
      images.push({mimeType:'image/jpeg',imageBase64:canvas.toDataURL('image/jpeg',0.82).split(',')[1]});
      canvas.width=canvas.height=1;
    }
    return images;
  }
  if(['image/jpeg','image/png','image/webp'].includes(file.type))return [{mimeType:file.type,imageBase64:await fileToBase64(file)}];
  if(!('createImageBitmap' in window))throw new Error('This image format is not supported in this browser. Try JPEG, PNG, or WebP.');
  const bitmap=await createImageBitmap(file),scale=Math.min(1,1800/bitmap.width),canvas=document.createElement('canvas');
  canvas.width=Math.ceil(bitmap.width*scale);canvas.height=Math.ceil(bitmap.height*scale);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  return [{mimeType:'image/jpeg',imageBase64:canvas.toDataURL('image/jpeg',0.84).split(',')[1]}];
}

// ---------- Patient: my prescriptions ----------
async function loadMyRx(){
  setMsg('rxMsg','',true);
  const { data, error } = await sb.from('prescriptions')
    .select('id,items,status,created_at,explanation,appointments(doctors(name))')
    .order('created_at',{ascending:false});
  if (error) { setMsg('rxMsg', error.message, false); return; }
  $('#rxList').innerHTML = data.length ? data.map(r=>`
    <div class="mrow rx-record" style="align-items:flex-start;flex-direction:column;gap:8px">
    <div style="display:flex;width:100%;gap:10px;align-items:flex-start">
    <span class="rx-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M6 3.5h8l4 4V20a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 20V5a1.5 1.5 0 0 1 2-1.5Z"/><path d="M14 4v4h4M8 12h6M8 15h8M8 18h5"/></svg></span>
    <span class="rx-copy"><small class="rx-kicker">PRESCRIBED BY</small><b>${r.appointments?.doctors?.name ?? 'Doctor'}</b><span class="rx-date"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2" y="3.5" width="12" height="10" rx="2"/><path d="M5 2v3m6-3v3M2 6.5h12"/></svg>${new Date(r.created_at).toLocaleDateString()}</span><span class="rx-items">${r.items}</span></span>
    <span class="pill ${r.status==='collected'?'done':r.status==='ready'?'called':'waiting'}">${r.status}</span>
    </div>
    ${r.explanation
      ? `<div class="ai-explain">${r.explanation.replace(/\n/g,'<br>')}</div>`
      : `<button type="button" data-explain-rx="${r.id}" data-items="${encodeURIComponent(r.items)}" class="go ai-explain-btn">Explain uses &amp; side effects</button>`}
    </div>`).join('') : "<p class='hint2'>No prescriptions yet.</p>";
  document.querySelectorAll('[data-explain-rx]').forEach(btn=>btn.onclick=async()=>{
    btn.disabled = true; btn.textContent = 'Thinking…';
    try {
      const res = await fetch(CHAT_API_URL.replace('/api/chat','/api/explain-prescription'), {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ items: decodeURIComponent(btn.dataset.items) })
      });
      if (!res.ok) throw new Error('status '+res.status);
      const data = await res.json();
      await sb.from('prescriptions').update({ explanation: data.explanation }).eq('id', btn.dataset.explainRx);
      loadMyRx();
    } catch(err){
      btn.disabled = false; btn.textContent = 'Explain uses & side effects';
      setMsg('rxMsg', "Couldn't reach the assistant backend — make sure server/ is running. ("+(err?.message||err)+")", false);
    }
  });
}

// ---------- Patient: complaints ----------
$('#btnFileComplaint').onclick = async ()=>{
  setMsg('compMsg','',true);
  const category = $('#compCategory').value, details = $('#compDetails').value.trim();
  $('#btnFileComplaint').disabled = true;
  const { data, error } = await sb.from('complaints').insert({ patient_id: currentUser.id, category, details }).select('tracking_id').single();
  $('#btnFileComplaint').disabled = false;
  if (error) { setMsg('compMsg', error.message, false); return; }
  $('#compMsg').innerHTML = 'Submitted. Your tracking ID: <span class="trackid">'+data.tracking_id+'</span>';
  $('#compDetails').value = '';
};
$('#btnCheckComplaint').onclick = async ()=>{
  setMsg('compStatusMsg','',true);
  const tid = $('#compTrackId').value.trim();
  if (!tid) { setMsg('compStatusMsg','Enter a tracking ID.', false); return; }
  const { data, error } = await sb.rpc('complaint_status', { tid });
  if (error) { setMsg('compStatusMsg', error.message, false); return; }
  if (!data || !data.length) { $('#compStatusResult').innerHTML = "<p class='hint2'>No complaint found for that ID.</p>"; return; }
  const c = data[0];
  $('#compStatusResult').innerHTML = `<div class="mrow"><span>${c.category}</span><span class="pill ${c.status==='resolved'?'done':c.status==='in_progress'?'called':'waiting'}">${c.status}</span></div>`;
};

// ---------- Staff: queue -> write prescription ----------
async function refreshRxApptOptions(){
  const doctor_id = $('#selQueueDoctor').value; if(!doctor_id) { $('#selRxAppt').innerHTML=''; return; }
  const today = new Date().toISOString().slice(0,10);
  const { data, error } = await sb.from('appointments')
    .select('id,token_no,profiles(full_name),walk_in_name')
    .eq('doctor_id', doctor_id).eq('status','called').gte('slot_time', today).order('token_no');
  if (error) return;
  $('#selRxAppt').innerHTML = data.length
    ? data.map(a=>`<option value="${a.id}">#${a.token_no} — ${a.profiles?.full_name || a.walk_in_name || 'Patient'}</option>`).join('')
    : '<option value="">No called patients</option>';
}
$('#btnWriteRx').onclick = async ()=>{
  setMsg('rxWriteMsg','',true);
  const appointment_id = $('#selRxAppt').value, items = $('#rxItems').value.trim();
  if (!appointment_id || !items) { setMsg('rxWriteMsg','Pick an appointment and enter items.', false); return; }
  $('#btnWriteRx').disabled = true;
  const { error } = await sb.from('prescriptions').insert({ appointment_id, items });
  $('#btnWriteRx').disabled = false;
  if (error) { setMsg('rxWriteMsg', error.message, false); return; }
  setMsg('rxWriteMsg','Prescription saved.', true);
  $('#rxItems').value='';
};

// ---------- Staff: pharmacy ----------
async function loadPharmacy(){
  setMsg('pharmMsg','',true);
  const { data, error } = await sb.from('prescriptions')
    .select('id,items,status,appointments(profiles(full_name),doctors(name))')
    .in('status',['pending','ready']).order('created_at');
  if (error) { setMsg('pharmMsg', error.message, false); return; }
  $('#pharmList').innerHTML = data.length ? data.map(r=>{
    const next = r.status==='pending' ? ['ready','Mark ready'] : ['collected','Mark collected'];
    return `<div class="mrow" style="align-items:flex-start;flex-direction:column;gap:4px">
    <div style="display:flex;justify-content:space-between;width:100%"><b>${r.appointments?.profiles?.full_name ?? 'Patient'}</b><span class="pill ${r.status==='ready'?'called':'waiting'}">${r.status}</span></div>
    <span class="hint2" style="color:var(--ink);opacity:.8">${r.items}</span>
    <button data-rx="${r.id}" data-next="${next[0]}" style="align-self:flex-end">${next[1]}</button>
    </div>`;
  }).join('') : "<p class='hint2'>Nothing pending.</p>";
  document.querySelectorAll('[data-rx]').forEach(b=>b.onclick=async()=>{
    const { error } = await sb.from('prescriptions').update({status:b.dataset.next}).eq('id', b.dataset.rx);
    if (error) { setMsg('pharmMsg', error.message, false); return; }
    loadPharmacy();
  });
}
async function loadStockHospitals(){
  const { data, error } = await sb.from('hospitals').select('id,name').order('name');
  if (error) { setMsg('stockMsg', error.message, false); return; }
  $('#selStockHospital').innerHTML = data.map(h=>`<option value="${h.id}">${h.name}</option>`).join('');
  loadStock();
}
$('#selStockHospital').onchange = loadStock;
async function loadStock(){
  const hid = $('#selStockHospital').value; if(!hid) return;
  const { data, error } = await sb.from('medicines').select('id,name,quantity,low_stock_level').eq('hospital_id',hid).order('name');
  if (error) { setMsg('stockMsg', error.message, false); return; }
  $('#stockList').innerHTML = data.length ? data.map(m=>`
    <div class="mrow"><span>${m.name}${m.quantity<=m.low_stock_level?' <span style="color:#D64545;font-size:11px;font-weight:700">LOW</span>':''}</span>
    <span><input type="number" class="stockqty" id="qty-${m.id}" value="${m.quantity}" min="0"> <button data-save-qty="${m.id}">Save</button></span></div>`).join('')
    : "<p class='hint2'>No medicines listed yet.</p>";
  document.querySelectorAll('[data-save-qty]').forEach(b=>b.onclick=async()=>{
    const id=b.dataset.saveQty, val=parseInt(document.getElementById('qty-'+id).value,10)||0;
    const { error } = await sb.from('medicines').update({quantity:val}).eq('id',id);
    if (error) { setMsg('stockMsg', error.message, false); return; }
    setMsg('stockMsg','Updated.', true); loadStock();
  });
}

// ---------- Staff: complaints ----------
async function loadStaffComplaints(){
  setMsg('scompMsg','',true);
  const { data, error } = await sb.from('complaints').select('id,tracking_id,category,details,status,created_at')
    .in('status',['open','in_progress']).order('created_at');
  if (error) { setMsg('scompMsg', error.message, false); return; }
  $('#scompList').innerHTML = data.length ? data.map(c=>{
    const next = c.status==='open' ? ['in_progress','Start working'] : ['resolved','Mark resolved'];
    return `<div class="mrow" style="align-items:flex-start;flex-direction:column;gap:4px">
    <div style="display:flex;justify-content:space-between;width:100%"><b>${c.category}</b><span class="pill ${c.status==='in_progress'?'called':'waiting'}">${c.status}</span></div>
    <span class="hint2" style="color:var(--ink);opacity:.8">#${c.tracking_id} — ${c.details||''}</span>
    <button data-comp="${c.id}" data-cnext="${next[0]}" style="align-self:flex-end">${next[1]}</button>
    </div>`;
  }).join('') : "<p class='hint2'>No open complaints.</p>";
  document.querySelectorAll('[data-comp]').forEach(b=>b.onclick=async()=>{
    const { error } = await sb.from('complaints').update({status:b.dataset.cnext}).eq('id', b.dataset.comp);
    if (error) { setMsg('scompMsg', error.message, false); return; }
    loadStaffComplaints();
  });
}


// ---------- Patient: bed availability ----------
async function loadBedHospitals(){
  const { data, error } = await sb.from('hospitals').select('id,name').order('name');
  if (error) { setMsg('bedsMsg', error.message, false); return; }
  $('#selBedHospital').innerHTML = data.map(h=>`<option value="${h.id}">${h.name}</option>`).join('');
  loadBeds();
}
$('#selBedHospital').onchange = loadBeds;
async function loadBeds(){
  const hid = $('#selBedHospital').value; if(!hid) return;
  const { data, error } = await sb.from('hospital_beds').select('id,ward_type,bed_no,status').eq('hospital_id',hid).order('ward_type').order('bed_no');
  if (error) { setMsg('bedsMsg', error.message, false); return; }
  const legacy=await sb.from('beds').select('ward_type,total_beds,occupied_beds').eq('hospital_id',hid).order('ward_type');
  if(legacy.error){setMsg('bedsMsg',legacy.error.message,false);return;}
  setMsg('bedsMsg',data.length?'Bed numbers show individual live status; wards without numbered records retain their ward totals.':(legacy.data.length?'Individual bed numbers are not registered yet; showing ward totals.':'No beds have been registered for this hospital yet.'),true);
  renderIndividualBeds(data,'#bedsList','#bedsWardFilters',false,legacy.data);
}
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function renderIndividualBeds(data,listSelector,filtersSelector,staff=false,legacyData=[]){
  const list=$(listSelector),filters=$(filtersSelector),active=filters.dataset.activeWard||'all';
  data.sort((a,b)=>a.ward_type.localeCompare(b.ward_type)||a.bed_no.localeCompare(b.bed_no,undefined,{numeric:true,sensitivity:'base'}));
  const wards=[...new Set([...data.map(bed=>bed.ward_type),...legacyData.map(bed=>bed.ward_type)])];
  filters.innerHTML=[['all','All wards'],...wards.map(ward=>[ward,ward])]
    .map(([key,label])=>`<button type="button" class="ward-filter ${key===active?'on':''}" data-ward-filter="${escapeHtml(key)}">${escapeHtml(label)}</button>`).join('');
  filters.querySelectorAll('[data-ward-filter]').forEach(button=>button.onclick=()=>{
    filters.dataset.activeWard=button.dataset.wardFilter;renderIndividualBeds(data,listSelector,filtersSelector,staff,legacyData);
  });
  const shown=data.filter(bed=>active==='all'||active===bed.ward_type);
  list.innerHTML=wards.length?wards.filter(ward=>active==='all'||active===ward).map(ward=>{
    const wardBeds=shown.filter(bed=>bed.ward_type===ward);
    const old=legacyData.find(bed=>bed.ward_type===ward);
    const legacySummary=old?`<span class="bed-legacy-count"><b>${Math.max(0,old.total_beds-old.occupied_beds)} available</b><span>${Math.max(0,old.occupied_beds)} occupied · ${old.total_beds} total</span></span>`:'';
    if(!wardBeds.length)return `<section class="bed-group"><div class="bed-group-heading"><strong>${escapeHtml(ward)}</strong><span>Ward totals</span></div><div class="bed-legacy-summary"><span class="bed-unit-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 19V6m0 9h18v4m0-8v8M3 15v-4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v4m0 0v-3a2 2 0 0 1 2-2h5a4 4 0 0 1 4 4"/></svg></span>${legacySummary}</div></section>`;
    const coverage=old&&wardBeds.length<old.total_beds?`<p class="bed-coverage">${wardBeds.length} of ${old.total_beds} beds have individual records. Add the remaining beds to complete this ward.</p>`:'';
    return `<section class="bed-group"><div class="bed-group-heading"><strong>${escapeHtml(ward)}</strong><span>${wardBeds.length} numbered beds</span></div><div class="bed-unit-grid">
      ${wardBeds.map(bed=>`<article class="bed-unit ${bed.status==='occupied'?'is-occupied':'is-available'}">
        <span class="bed-unit-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 19V6m0 9h18v4m0-8v8M3 15v-4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v4m0 0v-3a2 2 0 0 1 2-2h5a4 4 0 0 1 4 4"/></svg></span>
        <strong>Bed ${escapeHtml(bed.bed_no)}</strong><span class="bed-unit-status">${bed.status==='occupied'?'Occupied':'Available'}</span>
        ${staff?`<button type="button" class="bed-toggle" data-bed-id="${escapeHtml(bed.id)}" data-bed-status="${bed.status}">Mark ${bed.status==='occupied'?'available':'occupied'}</button>`:''}
      </article>`).join('')}
    </div>${coverage}</section>`;
  }).join(''):"<p class='hint2'>No numbered beds have been added for this hospital yet.</p>";
  if(staff)list.querySelectorAll('[data-bed-id]').forEach(button=>button.onclick=async()=>{
    button.disabled=true;
    const status=button.dataset.bedStatus==='occupied'?'available':'occupied';
    const { error }=await sb.from('hospital_beds').update({status,updated_at:new Date().toISOString()}).eq('id',button.dataset.bedId);
    if(error){button.disabled=false;setMsg('sbedsMsg',error.message,false);return;}
    setMsg('sbedsMsg','Bed status updated.',true);loadSBeds();
  });
}
$('#bedsWardFilters').dataset.activeWard='all';
$('#sbedsWardFilters').dataset.activeWard='all';

// ---------- Staff: walk-in registration ----------
async function loadWalkinDepts(){
  const { data, error } = await sb.from('departments').select('id,name').order('name');
  if (error) { setMsg('walkinMsg', error.message, false); return; }
  $('#selWiDept').innerHTML = data.map(d=>`<option value="${d.id}">${d.name}</option>`).join('');
  loadWalkinDoctors();
}
$('#selWiDept').onchange = loadWalkinDoctors;
async function loadWalkinDoctors(){
  const did = $('#selWiDept').value; if(!did) return;
  const { data, error } = await sb.from('doctors').select('id,name,available').eq('department_id',did).order('name');
  if (error) { setMsg('walkinMsg', error.message, false); return; }
  $('#selWiDoctor').innerHTML = data.map(d=>`<option value="${d.id}" ${d.available?'':'disabled'}>${d.name}${d.available?'':' (unavailable)'}</option>`).join('');
}
$('#btnWalkin').onclick = async ()=>{
  setMsg('walkinMsg','',true);
  const walk_in_name=$('#wiName').value.trim(), walk_in_mobile=$('#wiMobile').value.trim();
  const department_id=$('#selWiDept').value, doctor_id=$('#selWiDoctor').value;
  if(!walk_in_name || !doctor_id){ setMsg('walkinMsg','Enter a name and pick a doctor.', false); return; }
  $('#btnWalkin').disabled = true;
  const { data, error } = await sb.from('appointments')
    .insert({ walk_in_name, walk_in_mobile, department_id, doctor_id })
    .select('token_no').single();
  $('#btnWalkin').disabled = false;
  if (error) { setMsg('walkinMsg', error.message, false); return; }
  setMsg('walkinMsg', 'Added to queue — token #'+data.token_no, true);
  $('#wiName').value=''; $('#wiMobile').value='';
  loadQueue();
};

// ---------- Staff: bed management ----------
async function loadSBedHospitals(){
  const { data, error } = await sb.from('hospitals').select('id,name').order('name');
  if (error) { setMsg('sbedsMsg', error.message, false); return; }
  $('#selSBedHospital').innerHTML = data.map(h=>`<option value="${h.id}">${h.name}</option>`).join('');
  loadSBeds();
}
$('#selSBedHospital').onchange = loadSBeds;
async function loadSBeds(){
  const hid = $('#selSBedHospital').value; if(!hid) return;
  const { data, error } = await sb.from('hospital_beds').select('id,ward_type,bed_no,status').eq('hospital_id',hid).order('ward_type').order('bed_no');
  if (error) { setMsg('sbedsMsg', error.message, false); return; }
  const legacy=await sb.from('beds').select('ward_type,total_beds,occupied_beds').eq('hospital_id',hid).order('ward_type');
  if(legacy.error){setMsg('sbedsMsg',legacy.error.message,false);return;}
  setMsg('sbedsMsg',data.length?'Manage numbered beds; unregistered ward capacity remains available below.':(legacy.data.length?'Add individual bed numbers to manage live bed-level status.':'Add each hospital bed with its real ward and bed number.'),true);
  renderIndividualBeds(data,'#sbedsList','#sbedsWardFilters',true,legacy.data);
}
$('#btnAddBed').onclick=async()=>{
  const hospital_id=Number($('#selSBedHospital').value),ward_type=$('#bedWardName').value.trim(),bed_no=$('#bedNumber').value.trim(),button=$('#btnAddBed');
  if(!hospital_id||!ward_type||!bed_no){setMsg('sbedsMsg','Choose a hospital and enter both a ward and bed number.',false);return;}
  button.disabled=true;
  const {error}=await sb.from('hospital_beds').insert({hospital_id,ward_type,bed_no,status:'available'});
  button.disabled=false;
  if(error){setMsg('sbedsMsg',error.code==='23505'?'That bed number is already registered in this ward.':error.message,false);return;}
  $('#bedWardName').value='';$('#bedNumber').value='';
  $('#sbedsWardFilters').dataset.activeWard='all';
  setMsg('sbedsMsg','Bed added as available.',true);loadSBeds();
};

// ---------- Patient: upload & explain reports ----------
function fileToBase64(file){
  return new Promise((resolve,reject)=>{
    const r=new FileReader();
    r.onload=()=>resolve(r.result.split(',')[1]);
    r.onerror=()=>reject(new Error('Could not read that file.'));
    r.readAsDataURL(file);
  });
}
$('#btnUploadReport').onclick = async ()=>{
  setMsg('reportsMsg','',true);
  const input=$('#reportFile'), file=input.files && input.files[0];
  if(!file){ setMsg('reportsMsg','Choose a file first.', false); return; }
  if(file.size > 8*1024*1024){ setMsg('reportsMsg','Please choose a file under 8MB.', false); return; }
  const btn=$('#btnUploadReport'); btn.disabled=true; btn.textContent='Uploading…';
  try{
    const path = currentUser.id+'/'+Date.now()+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
    const { error: upErr } = await sb.storage.from('reports').upload(path, file);
    if (upErr) throw upErr;
    const { data: row, error: insErr } = await sb.from('reports')
      .insert({ patient_id: currentUser.id, file_path: path, file_name: file.name })
      .select('id').single();
    if (insErr) throw insErr;
    btn.textContent='Reading report…';
    const base64 = await fileToBase64(file);
    const res = await fetch(CHAT_API_URL.replace('/api/chat','/api/explain-report'), {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imageBase64: base64, mimeType: file.type || 'application/octet-stream' })
    });
    if (!res.ok) throw new Error('assistant backend status '+res.status);
    const data = await res.json();
    await sb.from('reports').update({ explanation: data.explanation }).eq('id', row.id);
    setMsg('reportsMsg','Done.', true);
    input.value='';
    loadReports();
  } catch(err){
    setMsg('reportsMsg', "Couldn't upload/explain that report. ("+(err?.message||err)+")", false);
  } finally {
    btn.disabled=false; btn.textContent='Upload & explain';
  }
};
async function loadReports(){
  const { data, error } = await sb.from('reports').select('id,file_name,explanation,created_at').order('created_at',{ascending:false});
  if (error) { setMsg('reportsMsg', error.message, false); return; }
  $('#reportsList').innerHTML = data.length ? data.map(r=>`
    <div class="mrow" style="align-items:flex-start;flex-direction:column;gap:6px">
    <div style="display:flex;justify-content:space-between;width:100%"><b>${r.file_name}</b><span class="hint2">${new Date(r.created_at).toLocaleDateString()}</span></div>
    ${r.explanation ? `<div class="ai-explain">${r.explanation.replace(/\n/g,'<br>')}</div>` : "<span class='hint2'>Explanation pending…</span>"}
    </div>`).join('') : "<p class='hint2'>No reports uploaded yet.</p>";
}

// ---------- Patient: health tips ----------
$('#btnGetTips').onclick = async ()=>{
  setMsg('tipsMsg','',true);
  const btn=$('#btnGetTips'); btn.disabled=true; btn.textContent='Thinking…';
  $('#tipsResult').innerHTML='';
  try{
    const res = await fetch(CHAT_API_URL.replace('/api/chat','/api/health-tips'), {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ activityLevel: $('#tipsActivity').value, diet: $('#tipsDiet').value, goal: $('#tipsGoal').value })
    });
    if (!res.ok) throw new Error('assistant backend status '+res.status);
    const data = await res.json();
    $('#tipsResult').innerHTML = `<div class="ai-explain">${(data.tips||'').replace(/\n/g,'<br>')}</div>`;
  } catch(err){
    setMsg('tipsMsg', "Couldn't reach the assistant backend — make sure server/ is running. ("+(err?.message||err)+")", false);
  } finally {
    btn.disabled=false; btn.textContent='Get suggestions';
  }
};

})();
