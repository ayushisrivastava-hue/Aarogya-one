-- Aarogya One: idempotent demo data.
-- Run this after schema.sql. Running it more than once is safe.

-- Repair serial sequences after imports, partial runs, or manually inserted IDs.
-- The next generated ID will always be greater than the current maximum.
select setval(pg_get_serial_sequence('public.hospitals', 'id'),
              coalesce((select max(id) from public.hospitals), 0) + 1, false);
select setval(pg_get_serial_sequence('public.departments', 'id'),
              coalesce((select max(id) from public.departments), 0) + 1, false);
select setval(pg_get_serial_sequence('public.doctors', 'id'),
              coalesce((select max(id) from public.doctors), 0) + 1, false);
select setval(pg_get_serial_sequence('public.medicines', 'id'),
              coalesce((select max(id) from public.medicines), 0) + 1, false);
select setval(pg_get_serial_sequence('public.beds', 'id'),
              coalesce((select max(id) from public.beds), 0) + 1, false);

insert into hospitals (name, district)
select 'District Hospital [Name]', '[District]'
where not exists (
  select 1 from hospitals where name = 'District Hospital [Name]' and district = '[District]'
);

insert into departments (hospital_id, name)
select h.id, d.name
from (values
  ('General Medicine'), ('Paediatrics'), ('Gynaecology'), ('Orthopaedics')
) as d(name)
cross join lateral (
  select id from hospitals
  where name = 'District Hospital [Name]' and district = '[District]'
  order by id limit 1
) h
where not exists (
  select 1 from departments existing
  where existing.hospital_id = h.id and existing.name = d.name
);

insert into doctors (department_id, name)
select d.id, doctor.name
from (values
  ('General Medicine', 'Dr. [Name 1]'),
  ('General Medicine', 'Dr. [Name 2]'),
  ('Paediatrics', 'Dr. [Name 3]'),
  ('Gynaecology', 'Dr. [Name 4]'),
  ('Orthopaedics', 'Dr. [Name 5]')
) as doctor(department_name, name)
cross join lateral (
  select dep.id
  from departments dep
  join hospitals h on h.id = dep.hospital_id
  where dep.name = doctor.department_name
    and h.name = 'District Hospital [Name]'
    and h.district = '[District]'
  order by dep.id limit 1
) d
where not exists (
  select 1 from doctors existing
  where existing.department_id = d.id and existing.name = doctor.name
);

insert into medicines (hospital_id, name, quantity, low_stock_level)
select h.id, medicine.name, medicine.quantity, medicine.low_stock_level
from (values
  ('Paracetamol 500 mg', 12, 20),
  ('ORS sachets', 18, 20),
  ('Amoxicillin 250 mg', 0, 20),
  ('Metformin 500 mg', 140, 30),
  ('Iron and folic acid', 90, 30)
) as medicine(name, quantity, low_stock_level)
cross join lateral (
  select id from hospitals
  where name = 'District Hospital [Name]' and district = '[District]'
  order by id limit 1
) h
where not exists (
  select 1 from medicines existing
  where existing.hospital_id = h.id and existing.name = medicine.name
);

insert into beds (hospital_id, ward_type, total_beds, occupied_beds)
select h.id, bed.ward_type, bed.total_beds, bed.occupied_beds
from (values
  ('General', 40, 27),
  ('ICU', 10, 6),
  ('Maternity', 15, 9),
  ('Pediatric', 12, 4)
) as bed(ward_type, total_beds, occupied_beds)
cross join lateral (
  select id from hospitals
  where name = 'District Hospital [Name]' and district = '[District]'
  order by id limit 1
) h
where not exists (
  select 1 from beds existing
  where existing.hospital_id = h.id and existing.ward_type = bed.ward_type
);

-- Create staff accounts in Supabase Authentication > Users, then assign roles:
-- update profiles set role = 'staff', hospital_id = 1 where id = '<user uuid>';
-- update profiles set role = 'pharmacist', hospital_id = 1 where id = '<user uuid>';
-- update profiles set role = 'admin', hospital_id = 1 where id = '<user uuid>';
