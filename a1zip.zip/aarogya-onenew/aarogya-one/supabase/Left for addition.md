Left for addition 
prescription check with ai
health tips integration with ai
more datasets
ahba linking
emergency services enhancements
chatbot efficiency better
merging the prescriptions with jan aushaudi generic medicine finder