-- Aarogya One: full schema repair. Run this WHOLE file in Supabase > SQL Editor.
--
-- What's likely happened: at some point, tables with these same names got
-- created with a different shape (from an earlier experiment, a partial
-- run, or a manual edit), and every later "create table if not exists"
-- silently did nothing, because the table already existed — just with the
-- wrong columns. That matches exactly what your screenshots show: real
-- tables, with specific columns genuinely missing.
--
-- This script is safe to run even if parts of it already succeeded: every
-- step either uses IF NOT EXISTS or is written to not fail on things that
-- are already correct.

create extension if not exists pgcrypto;

-- 1. Make sure every table exists at all (does nothing if it already does).
create table if not exists hospitals (
  id serial primary key, name text not null, district text
);
create table if not exists departments (
  id serial primary key, hospital_id int not null references hospitals(id) on delete cascade, name text not null
);
create table if not exists doctors (
  id serial primary key, department_id int not null references departments(id) on delete cascade,
  name text not null, available boolean not null default true
);
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists appointments ( id serial primary key );
create table if not exists medicines ( id serial primary key );
create table if not exists prescriptions ( id serial primary key );
create table if not exists complaints ( id serial primary key );
create table if not exists beds ( id serial primary key );
create table if not exists hospital_beds ( id uuid primary key default gen_random_uuid() );
create table if not exists reports ( id uuid primary key default gen_random_uuid() );

-- 2. Force every column to exist, on every table, regardless of what state
--    it was already in. This is the actual fix for what your screenshots show.
alter table profiles      add column if not exists full_name text;
alter table profiles      add column if not exists mobile text;
alter table profiles      add column if not exists role text not null default 'patient';
alter table profiles      add column if not exists health_id text;
alter table profiles      add column if not exists hospital_id int references hospitals(id);
alter table profiles      add column if not exists created_at timestamptz not null default now();

alter table appointments  add column if not exists patient_id uuid references profiles(id);
alter table appointments  add column if not exists walk_in_name text;
alter table appointments  add column if not exists walk_in_mobile text;
alter table appointments  add column if not exists doctor_id int references doctors(id);
alter table appointments  add column if not exists department_id int references departments(id);
alter table appointments  add column if not exists slot_time timestamptz not null default now();
alter table appointments  add column if not exists token_no int;
alter table appointments  add column if not exists priority boolean not null default false;
alter table appointments  add column if not exists status text not null default 'waiting';
alter table appointments  add column if not exists created_at timestamptz not null default now();
create index if not exists appointments_doctor_day on appointments (doctor_id, slot_time);

alter table medicines     add column if not exists hospital_id int references hospitals(id) on delete cascade;
alter table medicines     add column if not exists name text;
alter table medicines     add column if not exists quantity int not null default 0;
alter table medicines     add column if not exists low_stock_level int not null default 20;

alter table prescriptions add column if not exists appointment_id int references appointments(id) on delete cascade;
alter table prescriptions add column if not exists items text;
alter table prescriptions add column if not exists status text not null default 'pending';
alter table prescriptions add column if not exists created_at timestamptz not null default now();
alter table prescriptions add column if not exists explanation text;

alter table complaints    add column if not exists tracking_id text unique
  default upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
alter table complaints    add column if not exists patient_id uuid references profiles(id);
alter table complaints    add column if not exists hospital_id int references hospitals(id);
alter table complaints    add column if not exists category text;
alter table complaints    add column if not exists details text;
alter table complaints    add column if not exists status text not null default 'open';
alter table complaints    add column if not exists created_at timestamptz not null default now();

alter table beds          add column if not exists hospital_id int references hospitals(id) on delete cascade;
alter table beds          add column if not exists ward_type text;
alter table beds          add column if not exists total_beds int not null default 0;
alter table beds          add column if not exists occupied_beds int not null default 0;
alter table beds          add column if not exists updated_at timestamptz not null default now();

alter table hospital_beds add column if not exists hospital_id int references hospitals(id) on delete cascade;
alter table hospital_beds add column if not exists ward_type text;
alter table hospital_beds add column if not exists bed_no text;
alter table hospital_beds add column if not exists status text not null default 'available';
alter table hospital_beds add column if not exists created_at timestamptz not null default now();
alter table hospital_beds add column if not exists updated_at timestamptz not null default now();

alter table reports       add column if not exists patient_id uuid references profiles(id) on delete cascade;
alter table reports       add column if not exists file_path text;
alter table reports       add column if not exists file_name text;
alter table reports       add column if not exists explanation text;
alter table reports       add column if not exists created_at timestamptz not null default now();

-- 3. Recreate the functions/triggers (safe: these already use "or replace" / "if exists").
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles as existing_profile (id, full_name, mobile, health_id)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), ''),
    coalesce(nullif(new.raw_user_meta_data->>'mobile', ''), ''),
    lpad(floor(random() * 100000000000000)::bigint::text, 14, '0')
  )
  on conflict (id) do update
  set full_name = coalesce(nullif(excluded.full_name, ''), existing_profile.full_name, ''),
      mobile = coalesce(nullif(excluded.mobile, ''), existing_profile.mobile, ''),
      health_id = coalesce(existing_profile.health_id, excluded.health_id);
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.my_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.assign_token()
returns trigger language plpgsql as $$
begin
  perform pg_advisory_xact_lock(new.doctor_id);
  select coalesce(max(token_no), 0) + 1 into new.token_no
  from appointments where doctor_id = new.doctor_id and slot_time::date = new.slot_time::date;
  return new;
end $$;
drop trigger if exists appointments_assign_token on appointments;
create trigger appointments_assign_token before insert on appointments
  for each row execute function public.assign_token();

create or replace function public.complaint_status(tid text)
returns table (status text, category text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select status, category, created_at from public.complaints where tracking_id = upper(tid)
$$;

-- 4. Storage bucket for reports (does nothing if it already exists).
insert into storage.buckets (id, name, public) values ('reports', 'reports', false) on conflict (id) do nothing;
drop policy if exists "patients manage own report files" on storage.objects;
create policy "patients manage own report files" on storage.objects for all
  using (bucket_id = 'reports' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'reports' and (storage.foldername(name))[1] = auth.uid()::text);

-- 5. Make sure RLS is on everywhere it should be (safe to repeat).
alter table hospitals      enable row level security;
alter table departments    enable row level security;
alter table doctors        enable row level security;
alter table profiles       enable row level security;
alter table appointments   enable row level security;
alter table medicines      enable row level security;
alter table prescriptions  enable row level security;
alter table complaints     enable row level security;
alter table beds           enable row level security;
alter table hospital_beds  enable row level security;
alter table reports        enable row level security;

-- 6. THE OTHER LIKELY CAUSE: tell Supabase's API layer to drop its cached
--    picture of the schema and read it fresh. If the columns above already
--    existed and the error was really a stale cache, this line alone fixes it.
notify pgrst, 'reload schema';

-- 7. Verify: run this and check every table below has the columns you expect.
-- If any table is missing from this list entirely, paste that back to me.
select table_name, column_name, data_type
from information_schema.columns
where table_schema = 'public'
  and table_name in ('hospitals','departments','doctors','profiles','appointments',
                      'medicines','prescriptions','complaints','beds','hospital_beds','reports')
order by table_name, ordinal_position;
