-- Run this whole file in Supabase > SQL Editor.
-- Adds: a place to cache the AI's explanation of a prescription, a table
-- for uploaded reports + their AI explanation, and a private Storage
-- bucket (with per-patient folder access) to hold the uploaded report
-- files themselves.

-- 1. Cache an explanation on each prescription, so the AI isn't re-asked
--    every time the patient reopens the same prescription.
alter table prescriptions add column if not exists explanation text;

-- 2. Uploaded reports and their AI explanation.
create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references profiles(id) on delete cascade,
  file_path text not null,
  file_name text not null,
  explanation text,
  created_at timestamptz not null default now()
);
alter table reports enable row level security;

drop policy if exists "patients manage own reports" on reports;
create policy "patients manage own reports" on reports for all
  using (patient_id = auth.uid())
  with check (patient_id = auth.uid());

-- 3. Storage bucket for the report files themselves. Private — nothing in
--    it is public by default. Files are stored at "<user id>/<filename>",
--    and the policy below only allows a user to touch files inside their
--    own folder.
insert into storage.buckets (id, name, public)
values ('reports', 'reports', false)
on conflict (id) do nothing;

drop policy if exists "patients manage own report files" on storage.objects;
create policy "patients manage own report files" on storage.objects for all
  using (bucket_id = 'reports' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'reports' and (storage.foldername(name))[1] = auth.uid()::text);
