-- Aarogya One: Supabase schema (MVP). Run this whole file once in Supabase > SQL Editor.
-- The Health ID created here is a DEMO ID. It is NOT a real ABHA number.

create extension if not exists pgcrypto;

-- 1. Reference tables ---------------------------------------------------------
create table if not exists hospitals (
  id serial primary key,
  name text not null,
  district text
);

create table if not exists departments (
  id serial primary key,
  hospital_id int not null references hospitals(id) on delete cascade,
  name text not null
);

create table if not exists doctors (
  id serial primary key,
  department_id int not null references departments(id) on delete cascade,
  name text not null,
  available boolean not null default true
);

-- 2. Profiles (one per login) ---------------------------------------------------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  mobile text,
  role text not null default 'patient'
    check (role in ('patient','staff','pharmacist','admin')),
  health_id text unique,            -- demo ID, not a real ABHA
  hospital_id int references hospitals(id),
  created_at timestamptz not null default now()
);

-- Create a profile synchronously when someone signs up. The role is intentionally
-- assigned by the database default and never trusted from user metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles as existing_profile (id, full_name, mobile, health_id)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), ''),
    coalesce(nullif(new.raw_user_meta_data->>'mobile', ''), ''),
    lpad(floor(random() * 100000000000000)::bigint::text, 14, '0')
  )
  on conflict (id) do update
  set full_name = coalesce(nullif(excluded.full_name, ''), existing_profile.full_name, ''),
      mobile = coalesce(nullif(excluded.mobile, ''), existing_profile.mobile, ''),
      health_id = coalesce(existing_profile.health_id, excluded.health_id);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Helper: the role of the person making the request (avoids RLS recursion).
create or replace function public.my_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

-- 3. Appointments and queue ----------------------------------------------------
create table if not exists appointments (
  id serial primary key,
  patient_id uuid references profiles(id),      -- null for walk-ins without an account
  walk_in_name text,
  walk_in_mobile text,
  doctor_id int not null references doctors(id),
  department_id int not null references departments(id),
  slot_time timestamptz not null default now(),
  token_no int,
  priority boolean not null default false,
  status text not null default 'waiting'
    check (status in ('waiting','called','done','skipped','cancelled')),
  created_at timestamptz not null default now()
);
create index if not exists appointments_doctor_day on appointments (doctor_id, slot_time);

-- Next token number for that doctor and day.
create or replace function public.assign_token()
returns trigger language plpgsql as $$
begin
  perform pg_advisory_xact_lock(new.doctor_id);
  select coalesce(max(token_no), 0) + 1 into new.token_no
  from appointments
  where doctor_id = new.doctor_id and slot_time::date = new.slot_time::date;
  return new;
end $$;

drop trigger if exists appointments_assign_token on appointments;
create trigger appointments_assign_token
  before insert on appointments
  for each row execute function public.assign_token();

-- 4. Pharmacy ------------------------------------------------------------------
create table if not exists medicines (
  id serial primary key,
  hospital_id int not null references hospitals(id) on delete cascade,
  name text not null,
  quantity int not null default 0,
  low_stock_level int not null default 20
);

create table if not exists prescriptions (
  id serial primary key,
  appointment_id int not null references appointments(id) on delete cascade,
  items text not null,
  status text not null default 'pending'
    check (status in ('pending','ready','collected')),
  created_at timestamptz not null default now()
);

-- 5. Complaints ----------------------------------------------------------------
create table if not exists complaints (
  id serial primary key,
  tracking_id text not null unique
    default upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8)),
  patient_id uuid references profiles(id),      -- null when the complaint is anonymous
  hospital_id int references hospitals(id),
  category text not null,
  details text,
  status text not null default 'open'
    check (status in ('open','in_progress','resolved')),
  created_at timestamptz not null default now()
);

-- Anyone with the tracking ID can check status (no personal data returned).
create or replace function public.complaint_status(tid text)
returns table (status text, category text, created_at timestamptz)
language sql security definer set search_path = public as $$
  select c.status, c.category, c.created_at from complaints c where c.tracking_id = upper(tid)
$$;
grant execute on function public.complaint_status(text) to anon, authenticated;

-- 6. Row level security --------------------------------------------------------
alter table hospitals     enable row level security;
alter table departments   enable row level security;
alter table doctors       enable row level security;
alter table profiles      enable row level security;
alter table appointments  enable row level security;
alter table medicines     enable row level security;
alter table prescriptions enable row level security;
alter table complaints    enable row level security;

-- Re-running this file should replace policies instead of failing with
-- SQLSTATE 42710 (policy already exists).
drop policy if exists "read hospitals" on hospitals;
drop policy if exists "read departments" on departments;
drop policy if exists "read doctors" on doctors;
drop policy if exists "read medicines" on medicines;
drop policy if exists "admin manage hospitals" on hospitals;
drop policy if exists "admin manage departments" on departments;
drop policy if exists "admin manage doctors" on doctors;
drop policy if exists "pharmacy manage medicines" on medicines;
drop policy if exists "read own profile" on profiles;
drop policy if exists "staff read profiles" on profiles;
drop policy if exists "patient creates own profile" on profiles;
drop policy if exists "update own profile" on profiles;
drop policy if exists "patient reads own appointments" on appointments;
drop policy if exists "staff read appointments" on appointments;
drop policy if exists "patient books for self" on appointments;
drop policy if exists "staff create appointments" on appointments;
drop policy if exists "staff update appointments" on appointments;
drop policy if exists "patient cancels own" on appointments;
drop policy if exists "read prescriptions" on prescriptions;
drop policy if exists "doctor writes prescriptions" on prescriptions;
drop policy if exists "pharmacy updates prescriptions" on prescriptions;
drop policy if exists "file complaint" on complaints;
drop policy if exists "patient reads own complaints" on complaints;
drop policy if exists "staff read complaints" on complaints;
drop policy if exists "staff update complaints" on complaints;
drop policy if exists "read beds" on beds;
drop policy if exists "staff manage beds" on beds;
drop policy if exists "read hospital beds" on hospital_beds;
drop policy if exists "staff manage hospital beds" on hospital_beds;

-- Public reference data
create policy "read hospitals"   on hospitals   for select using (true);
create policy "read departments" on departments for select using (true);
create policy "read doctors"     on doctors     for select using (true);
create policy "read medicines"   on medicines   for select using (true);

create policy "admin manage hospitals"   on hospitals   for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "admin manage departments" on departments for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "admin manage doctors"     on doctors     for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "pharmacy manage medicines" on medicines  for all
  using (public.my_role() in ('pharmacist','admin')) with check (public.my_role() in ('pharmacist','admin'));

-- Profiles
create policy "read own profile"   on profiles for select using (id = auth.uid());
create policy "staff read profiles" on profiles for select using (public.my_role() in ('staff','pharmacist','admin'));
create policy "patient creates own profile" on profiles for insert
  with check (id = auth.uid() and role = 'patient');
create policy "update own profile" on profiles for update
  using (id = auth.uid()) with check (id = auth.uid() and role = public.my_role());  -- cannot change own role

-- Appointments
create policy "patient reads own appointments" on appointments for select using (patient_id = auth.uid());
create policy "staff read appointments" on appointments for select using (public.my_role() in ('staff','pharmacist','admin'));
create policy "patient books for self" on appointments for insert
  with check (patient_id = auth.uid() and public.my_role() = 'patient');
create policy "staff create appointments" on appointments for insert
  with check (public.my_role() in ('staff','admin'));
create policy "staff update appointments" on appointments for update
  using (public.my_role() in ('staff','admin')) with check (public.my_role() in ('staff','admin'));
create policy "patient cancels own" on appointments for update
  using (patient_id = auth.uid()) with check (patient_id = auth.uid() and status = 'cancelled');

-- Prescriptions
create policy "read prescriptions" on prescriptions for select using (
  public.my_role() in ('staff','pharmacist','admin')
  or exists (select 1 from appointments a where a.id = appointment_id and a.patient_id = auth.uid())
);
create policy "doctor writes prescriptions" on prescriptions for insert
  with check (public.my_role() in ('staff','admin'));
create policy "pharmacy updates prescriptions" on prescriptions for update
  using (public.my_role() in ('pharmacist','admin')) with check (public.my_role() in ('pharmacist','admin'));

-- Complaints
create policy "file complaint" on complaints for insert
  with check (patient_id is null or patient_id = auth.uid());
create policy "patient reads own complaints" on complaints for select using (patient_id = auth.uid());
create policy "staff read complaints" on complaints for select using (public.my_role() in ('staff','admin'));
create policy "staff update complaints" on complaints for update
  using (public.my_role() in ('staff','admin')) with check (public.my_role() in ('staff','admin'));

-- 7. Realtime (live queue, live stock) -------------------------------------------
do $$
declare table_name text;
begin
  foreach table_name in array array['appointments','prescriptions','medicines'] loop
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = table_name
    ) then
      execute format('alter publication supabase_realtime add table public.%I', table_name);
    end if;
  end loop;
end $$;

-- 8. Beds (ward-level availability, not individual bed tracking) ----------------
create table if not exists beds (
  id serial primary key,
  hospital_id int not null references hospitals(id) on delete cascade,
  ward_type text not null,                 -- e.g. 'General', 'ICU', 'Maternity', 'Pediatric'
  total_beds int not null default 0,
  occupied_beds int not null default 0 check (occupied_beds >= 0 and occupied_beds <= total_beds),
  updated_at timestamptz not null default now()
);
alter table beds enable row level security;
create policy "read beds" on beds for select using (true);
create policy "staff manage beds" on beds for all
  using (public.my_role() in ('staff','admin')) with check (public.my_role() in ('staff','admin'));
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'beds'
  ) then
    alter publication supabase_realtime add table public.beds;
  end if;
end $$;

-- 9. Individual bed inventory ---------------------------------------------------
create table if not exists hospital_beds (
  id uuid primary key default gen_random_uuid(),
  hospital_id int not null references hospitals(id) on delete cascade,
  ward_type text not null check (ward_type = btrim(ward_type) and ward_type <> ''),
  bed_no text not null check (bed_no = btrim(bed_no) and bed_no <> ''),
  status text not null default 'available' check (status in ('available','occupied')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (hospital_id, ward_type, bed_no)
);
alter table hospital_beds enable row level security;
create policy "read hospital beds" on hospital_beds for select using (true);
create policy "staff manage hospital beds" on hospital_beds for all
  using (public.my_role() in ('staff','admin'))
  with check (public.my_role() in ('staff','admin'));
grant select on hospital_beds to anon, authenticated;
grant insert, update, delete on hospital_beds to authenticated;
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'hospital_beds'
  ) then
    alter publication supabase_realtime add table public.hospital_beds;
  end if;
end $$;
