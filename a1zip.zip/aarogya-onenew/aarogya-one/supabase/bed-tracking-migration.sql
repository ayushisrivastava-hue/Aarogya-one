-- Adds individually numbered beds without inventing IDs or statuses from the
-- older ward-level totals in public.beds.

create table if not exists public.hospital_beds (
  id uuid primary key default gen_random_uuid(),
  hospital_id int not null references public.hospitals(id) on delete cascade,
  ward_type text not null check (ward_type = btrim(ward_type) and ward_type <> ''),
  bed_no text not null check (bed_no = btrim(bed_no) and bed_no <> ''),
  status text not null default 'available' check (status in ('available','occupied')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (hospital_id, ward_type, bed_no)
);

alter table public.hospital_beds enable row level security;

drop policy if exists "read hospital beds" on public.hospital_beds;
create policy "read hospital beds" on public.hospital_beds
  for select using (true);

drop policy if exists "staff manage hospital beds" on public.hospital_beds;
create policy "staff manage hospital beds" on public.hospital_beds
  for all
  using (public.my_role() in ('staff','admin'))
  with check (public.my_role() in ('staff','admin'));

grant select on public.hospital_beds to anon, authenticated;
grant insert, update, delete on public.hospital_beds to authenticated;

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'hospital_beds'
  ) then
    alter publication supabase_realtime add table public.hospital_beds;
  end if;
end;
$$;
