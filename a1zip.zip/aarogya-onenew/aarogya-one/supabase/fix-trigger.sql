-- Run once in Supabase > SQL Editor to install/repair profile creation.
-- Profiles intentionally do not duplicate auth.users.email. Roles are assigned
-- by the database default, never from client-provided user metadata.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles as existing_profile (id, full_name, mobile, health_id)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), ''),
    coalesce(nullif(new.raw_user_meta_data->>'mobile', ''), ''),
    lpad(floor(random() * 100000000000000)::bigint::text, 14, '0')
  )
  on conflict (id) do update
  set full_name = coalesce(nullif(excluded.full_name, ''), existing_profile.full_name, ''),
      mobile = coalesce(nullif(excluded.mobile, ''), existing_profile.mobile, ''),
      health_id = coalesce(existing_profile.health_id, excluded.health_id);

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
drop policy if exists "patient creates own profile" on public.profiles;
create policy "patient creates own profile" on public.profiles
  for insert
  with check (id = auth.uid() and role = 'patient');

-- Repair missing profiles for accounts that predate the trigger.
insert into public.profiles (id, full_name, mobile, health_id)
select
  u.id,
  coalesce(nullif(u.raw_user_meta_data->>'full_name', ''), ''),
  coalesce(nullif(u.raw_user_meta_data->>'mobile', ''), ''),
  lpad(floor(random() * 100000000000000)::bigint::text, 14, '0')
from auth.users as u
left join public.profiles as p on p.id = u.id
where p.id is null
on conflict (id) do nothing;

-- Confirm that every auth user has a matching profile.
select u.email, p.role, p.health_id
from auth.users as u
left join public.profiles as p on p.id = u.id
order by u.created_at;
